#!/usr/bin/env python3
"""Optional Acc-vs-BCR scatter from frozen CSV (NOT bit-exact to manuscript fig3 PDF)."""

from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "rebuilt"
SRC = ROOT / "results" / "scaled" / "system_results.csv"

# Headline systems shown in manuscript Table symbolic / Fig 3 spirit
KEEP = {
    "B2_latest_only",
    "B3_recency_k3",
    "B3_recency_k8",
    "B4_bm25_k8",
    "B1_flat_cap150_compact",
    "H0_ltkm_cap150_ret8",
}


def main() -> None:
    try:
        import matplotlib.pyplot as plt
    except ImportError as e:
        raise SystemExit(
            "matplotlib not installed; data export still available via export_figure_table_data.py"
        ) from e

    rows = [r for r in csv.DictReader(SRC.open()) if r["system"] in KEEP]
    xs = [float(r["mean_query_accuracy"]) for r in rows]
    ys = [float(r["bcr"]) for r in rows]
    labels = [r["system"] for r in rows]

    OUT.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(xs, ys)
    for x, y, lab in zip(xs, ys, labels):
        ax.annotate(lab.replace("_", "\n"), (x, y), fontsize=7)
    ax.set_xlabel("Acc")
    ax.set_ylabel("BCR")
    ax.set_title("Rebuilt Acc vs BCR (not manuscript PDF)")
    ax.set_xlim(0, 1.05)
    ax.set_ylim(-0.05, 1.05)
    ax.grid(True, alpha=0.3)
    out = OUT / "fig3-acc-vs-bcr-csr.png"
    fig.tight_layout()
    fig.savefig(out, dpi=150)
    print("wrote", out)
    print("NOTE: illustrative only; manuscript uses static PDF artwork.")


if __name__ == "__main__":
    main()
