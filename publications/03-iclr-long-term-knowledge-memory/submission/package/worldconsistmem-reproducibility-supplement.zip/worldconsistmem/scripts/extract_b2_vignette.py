#!/usr/bin/env python3
"""Extract a frozen B2 qualitative vignette (read-only; does not mutate Option A).

Default target: ss0100_000:b:ceo:0 under system B2_latest_only.
Serializes ConstraintResult via to_dict() (primitive fields only).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.io_util import read_jsonl  # noqa: E402
from worldconsistmem.metrics import answers_equal, evaluate_bundle  # noqa: E402
from worldconsistmem.models import (  # noqa: E402
    AnswerSchema,
    ConstraintFamily,
    ConstraintResult,
    Query,
    QueryBundle,
    QueryFamily,
)
from worldconsistmem.predict import prediction_from_dict  # noqa: E402
from worldconsistmem.scaled_generate import generate_scaled_world  # noqa: E402

DEFAULT_BUNDLE_ID = "ss0100_000:b:ceo:0"
DEFAULT_SYSTEM = "B2_latest_only"
DEFAULT_WORLD_ID = "ss0100_000"
DEFAULT_SEED = 100
DEFAULT_WORLD_IDX = 0
DEFAULT_TIER = "small"


def constraint_result_to_primitives(result: ConstraintResult) -> dict[str, Any]:
    """Stable primitive serialization (regression target for prior .get() failure)."""
    if not isinstance(result, ConstraintResult):
        raise TypeError(f"expected ConstraintResult, got {type(result)!r}")
    out = result.to_dict()
    # Ensure JSON-safe primitives only
    json.dumps(out)
    return out


def load_bundle(bundles_path: Path, bundle_id: str) -> QueryBundle:
    brow = next(r for r in read_jsonl(bundles_path) if r["bundle_id"] == bundle_id)
    queries = []
    for q in brow["queries"]:
        queries.append(
            Query(
                query_id=q["query_id"],
                bundle_id=q["bundle_id"],
                family=QueryFamily(q["family"]),
                text=q["text"],
                structured=q.get("structured") or {},
                gold_answer=q["gold_answer"],
                answer_schema=AnswerSchema(q["answer_schema"]),
                target_time=q.get("target_time"),
                target_interval=q.get("target_interval"),
                supporting_event_ids=q.get("supporting_event_ids") or [],
                supporting_provenance_ids=q.get("supporting_provenance_ids") or [],
                applicable_constraints=[
                    ConstraintFamily(c) for c in (q.get("applicable_constraints") or [])
                ],
                metadata=q.get("metadata") or {},
            )
        )
    return QueryBundle(
        bundle_id=brow["bundle_id"],
        world_id=brow["world_id"],
        focal_entities=brow.get("focal_entities") or [],
        queries=queries,
        description=brow.get("description") or "",
        metadata=brow.get("metadata") or {},
    )


def extract_vignette(
    *,
    root: Path = ROOT,
    bundle_id: str = DEFAULT_BUNDLE_ID,
    system_id: str = DEFAULT_SYSTEM,
    world_id: str = DEFAULT_WORLD_ID,
    seed: int = DEFAULT_SEED,
    world_idx: int = DEFAULT_WORLD_IDX,
    tier: str = DEFAULT_TIER,
) -> dict[str, Any]:
    world_path = root / "data" / "scaled" / "worlds" / f"{world_id}.json"
    bundles_path = root / "data" / "scaled" / "bundles.jsonl"
    pred_path = root / "results" / "scaled" / "predictions" / f"{system_id}.jsonl"

    w = generate_scaled_world(seed, world_idx, tier)
    if w.world_id != world_id:
        raise RuntimeError(f"world_id mismatch: generated {w.world_id} != {world_id}")
    wraw = json.loads(world_path.read_text())
    if [e.event_id for e in w.events] != [e["event_id"] for e in wraw["events"]]:
        raise RuntimeError("regenerated world events do not match frozen world JSON")

    bundle = load_bundle(bundles_path, bundle_id)
    pred_rows = [r for r in read_jsonl(pred_path) if r["bundle_id"] == bundle_id]
    if len(pred_rows) != len(bundle.queries):
        raise RuntimeError(
            f"prediction count {len(pred_rows)} != query count {len(bundle.queries)}"
        )
    preds = [prediction_from_dict(r) for r in pred_rows]
    if any(p.system_id != system_id for p in preds):
        raise RuntimeError("prediction system_id mismatch")

    bm = evaluate_bundle(w, bundle, preds)
    pmap = {p.query_id: p for p in preds}

    items = []
    for q in bundle.queries:
        p = pmap[q.query_id]
        ok = bool(answers_equal(p.predicted_answer, q.gold_answer))
        items.append(
            {
                "query_id": q.query_id,
                "family": q.family.value,
                "slot": (q.metadata or {}).get("slot"),
                "gold_answer": q.gold_answer,
                "predicted_answer": p.predicted_answer,
                "item_correct": ok,
                "acc_i": 1.0 if ok else 0.0,
            }
        )

    violations = [
        constraint_result_to_primitives(r) for r in bm.constraint_results if not r.passed
    ]
    all_constraints = [constraint_result_to_primitives(r) for r in bm.constraint_results]

    record = {
        "vignette_id": "b2_ceo_succession_ss0100_000",
        "bundle_id": bundle_id,
        "world_id": world_id,
        "system_id": system_id,
        "system_note": "B2 denotes the latest-only baseline system, not a difficulty tier.",
        "world_tier": (bundle.metadata or {}).get("tier"),
        "bundle_difficulty": (bundle.metadata or {}).get("difficulty"),
        "n_queries": bm.n_queries,
        "mean_query_accuracy": bm.mean_query_accuracy,
        "bundle_phi": bm.consistent,
        "bundle_bcr_contribution": 1.0 if bm.consistent else 0.0,
        "n_correct": int(sum(1 for it in items if it["item_correct"])),
        "items": items,
        "constraint_results": all_constraints,
        "violations": violations,
        "sources": {
            "world_json": str(world_path.relative_to(root)),
            "world_json_sha256": hashlib.sha256(world_path.read_bytes()).hexdigest(),
            "bundles_jsonl": str(bundles_path.relative_to(root)),
            "predictions_jsonl": str(pred_path.relative_to(root)),
            "predictions_jsonl_sha256": hashlib.sha256(pred_path.read_bytes()).hexdigest(),
        },
        "narrative_checks": {
            "acc_equals_0_75": abs(bm.mean_query_accuracy - 0.75) < 1e-12,
            "bcr_bundle_equals_0": bm.consistent is False,
            "historical_abstains": any(
                it["family"] == "historical_state"
                and it["predicted_answer"] == "__ABSTAIN__"
                for it in items
            ),
            "current_correct": any(
                it["family"] == "current_state" and it["item_correct"] for it in items
            ),
            "transition_correct": any(
                it["family"] == "transition" and it["item_correct"] for it in items
            ),
            "n_queries_is_8": bm.n_queries == 8,
            "n_correct_is_6": int(sum(1 for it in items if it["item_correct"])) == 6,
        },
    }
    return record


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--out",
        type=Path,
        default=ROOT / "results" / "new" / "b2_vignette_ss0100_ceo0.json",
    )
    ap.add_argument("--bundle-id", default=DEFAULT_BUNDLE_ID)
    args = ap.parse_args()
    record = extract_vignette(bundle_id=args.bundle_id)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    checks = record["narrative_checks"]
    print(json.dumps({"out": str(args.out), "checks": checks, "Acc": record["mean_query_accuracy"], "Phi": record["bundle_phi"]}, indent=2))
    if not all(checks.values()):
        print("WARNING: narrative_checks not all true", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
