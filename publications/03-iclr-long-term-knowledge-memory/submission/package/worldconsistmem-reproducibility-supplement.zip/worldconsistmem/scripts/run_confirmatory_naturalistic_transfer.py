#!/usr/bin/env python3
"""Confirmatory naturalistic transfer set (bounded; labelled NEW/confirmatory).

Freeze ≥30 scenarios with NL narratives + joint-evaluable belief sets.
Readers: gold, narrative_heuristic, last_event_heuristic, entity_prior.
Does not mutate Option A.
"""

from __future__ import annotations

import hashlib
import json
import random
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.metrics import answers_equal  # noqa: E402
from worldconsistmem.stats_world import bootstrap_ci, mean  # noqa: E402

OUT = ROOT / "results" / "confirmatory" / "naturalistic_transfer"
SEED = 20260908
N_SCENARIOS = 36  # preregistered target
DOMAINS = (
    "organizational_roles",
    "object_locations",
    "reservations",
    "access_permissions",
    "ownership",
    "project_responsibility",
)


@dataclass
class Scenario:
    scenario_id: str
    domain: str
    narrative: str
    queries: list[dict[str, Any]]
    gold: dict[str, Any]
    entities: dict[str, str]
    metadata: dict[str, Any] = field(default_factory=dict)


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def build_scenarios(rng: random.Random) -> list[Scenario]:
    first = [
        "Alex",
        "Blair",
        "Casey",
        "Drew",
        "Eden",
        "Flynn",
        "Grey",
        "Harper",
        "Indigo",
        "Jules",
        "Kai",
        "Logan",
    ]
    orgs = [
        "Northwind Labs",
        "Cedar Systems",
        "Harbor Works",
        "Maple Robotics",
        "Summit Health",
        "River Analytics",
    ]
    objects = [
        "tablet",
        "badge",
        "projector",
        "keys",
        "drone",
        "laptop",
    ]
    places = [
        "front desk",
        "lab A",
        "storage closet",
        "conference room 2",
        "loading bay",
        "office 14",
    ]
    out: list[Scenario] = []
    for i in range(N_SCENARIOS):
        domain = DOMAINS[i % len(DOMAINS)]
        a, b = rng.sample(first, 2)
        org = orgs[i % len(orgs)]
        obj = objects[i % len(objects)]
        p0, p1 = places[i % len(places)], places[(i + 3) % len(places)]
        sid = f"ntl{SEED}_{i:03d}"
        if domain == "organizational_roles":
            narrative = (
                f"At {org}, {a} served as CEO through March. In April, the board appointed {b} as CEO, "
                f"and {a} stepped down. By June, {b} was the sitting CEO. The appointment minutes list "
                f"the April handover from {a} to {b}."
            )
            gold = {
                "current": b,
                "historical": a,
                "transition": {"from": a, "to": b, "when": "April"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": f"Who is the CEO of {org} now (June)?", "gold_key": "current"},
                {"role": "historical_state", "text": f"Who was CEO of {org} before the April change?", "gold_key": "historical"},
                {"role": "transition", "text": f"Who succeeded whom as CEO of {org} in April?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Did {a}'s CEO term end before {b}'s term began?", "gold_key": "temporal_order"},
            ]
            entities = {"P0": a, "P1": b, "ORG": org}
        elif domain == "object_locations":
            narrative = (
                f"The {obj} was kept at the {p0}. On Tuesday it was moved to the {p1}. "
                f"Staff confirmed the move from {p0} to {p1}. On Wednesday the {obj} remained at the {p1}."
            )
            gold = {
                "current": p1,
                "historical": p0,
                "transition": {"from": p0, "to": p1, "when": "Tuesday"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": f"Where is the {obj} on Wednesday?", "gold_key": "current"},
                {"role": "historical_state", "text": f"Where was the {obj} before Tuesday?", "gold_key": "historical"},
                {"role": "transition", "text": f"Where was the {obj} moved from and to on Tuesday?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Was the {obj} at the {p0} before it was at the {p1}?", "gold_key": "temporal_order"},
            ]
            entities = {"OBJ": obj, "LOC0": p0, "LOC1": p1}
        elif domain == "reservations":
            room = f"Room {10 + (i % 7)}"
            narrative = (
                f"{a} held the reservation for {room} on Monday morning. At noon, the reservation was "
                f"transferred to {b}. By Monday evening, {b} held {room}. The desk log records the noon transfer from {a} to {b}."
            )
            gold = {
                "current": b,
                "historical": a,
                "transition": {"from": a, "to": b, "when": "noon"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": f"Who holds the reservation for {room} on Monday evening?", "gold_key": "current"},
                {"role": "historical_state", "text": f"Who held {room} before the noon transfer?", "gold_key": "historical"},
                {"role": "transition", "text": f"Who received the {room} reservation from whom at noon?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Did {a}'s hold end before {b}'s hold began?", "gold_key": "temporal_order"},
            ]
            entities = {"P0": a, "P1": b, "ROOM": room}
        elif domain == "access_permissions":
            narrative = (
                f"{a} had badge access to the secure vault until Friday. On Friday afternoon access was "
                f"revoked from {a} and granted to {b}. On Saturday, only {b} had vault access. Security notes "
                f"record the Friday switch from {a} to {b}."
            )
            gold = {
                "current": b,
                "historical": a,
                "transition": {"from": a, "to": b, "when": "Friday"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": "Who has vault access on Saturday?", "gold_key": "current"},
                {"role": "historical_state", "text": "Who had vault access before Friday afternoon?", "gold_key": "historical"},
                {"role": "transition", "text": "Who gained vault access from whom on Friday?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Did {a} lose access before {b} gained it?", "gold_key": "temporal_order"},
            ]
            entities = {"P0": a, "P1": b}
        elif domain == "ownership":
            narrative = (
                f"{a} owned the patent portfolio through 2022. In 2023 ownership transferred to {b}. "
                f"In 2024, {b} remained the owner. The deed lists the 2023 transfer from {a} to {b}."
            )
            gold = {
                "current": b,
                "historical": a,
                "transition": {"from": a, "to": b, "when": "2023"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": "Who owns the patent portfolio in 2024?", "gold_key": "current"},
                {"role": "historical_state", "text": "Who owned it before the 2023 transfer?", "gold_key": "historical"},
                {"role": "transition", "text": "Who received ownership from whom in 2023?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Did {a}'s ownership end before {b}'s began?", "gold_key": "temporal_order"},
            ]
            entities = {"P0": a, "P1": b}
        else:  # project_responsibility
            proj = f"Project {chr(65 + (i % 6))}"
            narrative = (
                f"{a} led {proj} through sprint 3. In sprint 4, leadership moved to {b}. "
                f"In sprint 5, {b} was still the lead. The changelog records the sprint-4 handoff from {a} to {b}."
            )
            gold = {
                "current": b,
                "historical": a,
                "transition": {"from": a, "to": b, "when": "sprint 4"},
                "temporal_order": True,
            }
            queries = [
                {"role": "current_state", "text": f"Who leads {proj} in sprint 5?", "gold_key": "current"},
                {"role": "historical_state", "text": f"Who led {proj} before sprint 4?", "gold_key": "historical"},
                {"role": "transition", "text": f"Who took over {proj} from whom in sprint 4?", "gold_key": "transition"},
                {"role": "temporal_order", "text": f"Did {a}'s leadership end before {b}'s began?", "gold_key": "temporal_order"},
            ]
            entities = {"P0": a, "P1": b, "PROJ": proj}

        out.append(
            Scenario(
                scenario_id=sid,
                domain=domain,
                narrative=narrative,
                queries=queries,
                gold=gold,
                entities=entities,
                metadata={"seed": SEED, "index": i},
            )
        )
    return out


def phi_constraints(pred: dict[str, Any], gold: dict[str, Any]) -> tuple[bool, list[str]]:
    """Joint constraints mirroring WorldConsistMem-style ∀c on the 4-slot belief set."""
    fails = []
    # transition reconciles historical/current
    tr = pred.get("transition")
    if not isinstance(tr, dict):
        fails.append("transition_shape")
    else:
        if tr.get("from") != pred.get("historical") or tr.get("to") != pred.get("current"):
            fails.append("transition_vs_roles")
        if gold["transition"].get("from") and tr.get("from") != gold["transition"]["from"]:
            # still allow phi on predicted internal consistency even if factually wrong? 
            # Primary Φ here = compatibility of predicted set + factual slots for transfer study:
            # We require predicted transition matches predicted hist/current AND temporal_order coherent.
            pass
    if pred.get("historical") == pred.get("current") and pred.get("historical") is not None:
        # succession domains require change
        fails.append("no_change_but_transition_expected")
    if pred.get("temporal_order") is not True and pred.get("temporal_order") != gold["temporal_order"]:
        # if abstaining/wrong temporal
        if pred.get("temporal_order") != True:
            fails.append("temporal_order")
    # Require non-null hist/current for Φ
    if pred.get("historical") in (None, "__ABSTAIN__") or pred.get("current") in (None, "__ABSTAIN__"):
        fails.append("missing_role")
    if pred.get("transition") in (None, "__ABSTAIN__"):
        fails.append("missing_transition")
    return (len(fails) == 0), fails


def reader_gold(sc: Scenario) -> dict[str, Any]:
    return dict(sc.gold)


def reader_narrative_heuristic(sc: Scenario) -> dict[str, Any]:
    """Extract roles from narrative cues (to/from/appointed/moved). Imperfect NL reader."""
    text = sc.narrative
    # current: last mentioned successor pattern
    pred: dict[str, Any] = {
        "current": None,
        "historical": None,
        "transition": "__ABSTAIN__",
        "temporal_order": "__ABSTAIN__",
    }
    # domain-general: find "from X to Y" or "X to Y"
    m = re.search(
        r"(?:from|handover from|transfer(?:red)? from|switch from|hand-?off from)\s+([A-Z][a-z]+|the [^,]+?)\s+to\s+([A-Z][a-z]+|the [^,.]+)",
        text,
    )
    if not m:
        m = re.search(r"moved (?:from )?(.+?) to (?:the )?(.+?)\.", text)
    if m:
        frm, to = m.group(1).strip(), m.group(2).strip()
        frm = frm.removeprefix("the ").strip()
        to = to.removeprefix("the ").strip()
        pred["historical"] = frm
        pred["current"] = to
        # when cue
        when = None
        for cue in ("April", "Tuesday", "noon", "Friday", "2023", "sprint 4"):
            if cue in text:
                when = cue
                break
        pred["transition"] = {"from": frm, "to": to, "when": when}
        pred["temporal_order"] = True
    else:
        # fallback: first and second proper names
        names = re.findall(r"\b([A-Z][a-z]+)\b", text)
        stop = {"At", "In", "On", "By", "The", "Staff", "Security", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "April", "March", "June", "Project", "Room", "CEO"}
        names = [n for n in names if n not in stop]
        if len(names) >= 2:
            pred["historical"] = names[0]
            pred["current"] = names[1]
            pred["transition"] = {"from": names[0], "to": names[1], "when": None}
            pred["temporal_order"] = True
    return pred


def reader_last_event(sc: Scenario) -> dict[str, Any]:
    """Recency-only: use only the last sentence; often loses historical."""
    last = sc.narrative.strip().split(".")[-2] if "." in sc.narrative else sc.narrative
    # Only recover current-like entity; abstain elsewhere
    names = re.findall(r"\b([A-Z][a-z]+)\b", last)
    stop = {"The", "On", "In", "By", "Staff", "Security", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "April", "March", "June", "Project", "Room"}
    names = [n for n in names if n not in stop]
    cur = names[-1] if names else "__ABSTAIN__"
    return {
        "current": cur,
        "historical": "__ABSTAIN__",
        "transition": "__ABSTAIN__",
        "temporal_order": "__ABSTAIN__",
    }


def reader_entity_prior(sc: Scenario) -> dict[str, Any]:
    """Shortcut: always answer with the first entity as current; ignore history."""
    e = sc.entities
    first = e.get("P1") or e.get("LOC1") or next(iter(e.values()))
    return {
        "current": first,
        "historical": first,
        "transition": {"from": first, "to": first, "when": None},
        "temporal_order": False,
    }


READERS = {
    "gold": reader_gold,
    "narrative_heuristic": reader_narrative_heuristic,
    "last_event_heuristic": reader_last_event,
    "entity_prior": reader_entity_prior,
}


def score_scenario(sc: Scenario, pred: dict[str, Any]) -> dict[str, Any]:
    roles = ["current", "historical", "transition", "temporal_order"]
    correct = {}
    for role in roles:
        correct[role] = bool(answers_equal(pred.get(role), sc.gold.get(role)))
    acc = mean([1.0 if correct[r] else 0.0 for r in roles])
    # Φ: predicted belief set internally satisfies succession constraints AND temporal_order true when roles differ
    ok_phi, fails = True, []
    if pred.get("historical") in (None, "__ABSTAIN__") or pred.get("current") in (None, "__ABSTAIN__"):
        ok_phi = False
        fails.append("missing_role")
    tr = pred.get("transition")
    if not isinstance(tr, dict):
        ok_phi = False
        fails.append("transition_shape")
    else:
        if tr.get("from") != pred.get("historical") or tr.get("to") != pred.get("current"):
            ok_phi = False
            fails.append("transition_mismatch")
    if pred.get("temporal_order") is not True:
        ok_phi = False
        fails.append("temporal_order")
    if pred.get("historical") == pred.get("current"):
        ok_phi = False
        fails.append("no_actual_change")
    return {
        "acc": acc,
        "phi": ok_phi,
        "per_role_correct": correct,
        "phi_failures": fails,
        "pred": pred,
    }


def validate_scenarios(scenarios: list[Scenario]) -> dict[str, Any]:
    issues = []
    ids = [s.scenario_id for s in scenarios]
    if len(ids) != len(set(ids)):
        issues.append("duplicate_ids")
    for s in scenarios:
        if len(s.narrative.split()) < 20:
            issues.append(f"short_narrative:{s.scenario_id}")
        # gold consistency
        g = s.gold
        if g["transition"]["from"] != g["historical"] or g["transition"]["to"] != g["current"]:
            issues.append(f"gold_transition_inconsistent:{s.scenario_id}")
        if g["historical"] == g["current"]:
            issues.append(f"gold_no_change:{s.scenario_id}")
        if g["temporal_order"] is not True:
            issues.append(f"gold_temporal:{s.scenario_id}")
        # no answer leakage of form "answer is"
        if re.search(r"\banswer\s*:", s.narrative, re.I):
            issues.append(f"leakage:{s.scenario_id}")
    # manual sample procedure: first 3 ids under seed order + every 12th
    sample_ids = [scenarios[i].scenario_id for i in [0, 1, 2, 12, 24]]
    return {
        "n_scenarios": len(scenarios),
        "n_issues": len(issues),
        "issues": issues,
        "manual_inspection_sample_ids": sample_ids,
        "manual_inspection_procedure": (
            "Inspect sample_ids for grammar, unambiguous entities, no answer leakage, "
            "and gold transition consistency. Deterministic validator checks state consistency for all."
        ),
        "pass": len(issues) == 0,
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rng = random.Random(SEED)
    scenarios = build_scenarios(rng)
    # Freeze config
    config = {
        "seed": SEED,
        "n_scenarios": N_SCENARIOS,
        "domains": list(DOMAINS),
        "queries_per_scenario": 4,
        "primary_analysis": "scenario-level mean Acc and BCR(=mean Φ) with bootstrap CI over scenarios",
        "exclusion_criteria": "none pre-registered; validator must pass with zero gold inconsistencies",
        "label": "confirmatory_naturalistic_transfer",
        "not_option_a": True,
        "scope": "bounded transfer to controlled NL narratives; not real-world validity",
    }
    val = validate_scenarios(scenarios)
    assert val["pass"], val

    # Write frozen scenarios
    scen_path = OUT / "scenarios.jsonl"
    with scen_path.open("w") as f:
        for s in scenarios:
            f.write(
                json.dumps(
                    {
                        "scenario_id": s.scenario_id,
                        "domain": s.domain,
                        "narrative": s.narrative,
                        "queries": s.queries,
                        "gold": s.gold,
                        "entities": s.entities,
                        "metadata": s.metadata,
                    },
                    sort_keys=True,
                )
                + "\n"
            )

    # Evaluate readers
    reader_summaries = {}
    predictions_out = []
    for rname, rfn in READERS.items():
        rows = []
        for s in scenarios:
            pred = rfn(s)
            sc = score_scenario(s, pred)
            rows.append({"scenario_id": s.scenario_id, "domain": s.domain, **sc})
            predictions_out.append(
                {"reader": rname, "scenario_id": s.scenario_id, "pred": pred, "acc": sc["acc"], "phi": sc["phi"]}
            )
        accs = [r["acc"] for r in rows]
        phis = [1.0 if r["phi"] else 0.0 for r in rows]
        reader_summaries[rname] = {
            "n": len(rows),
            "mean_acc": mean(accs),
            "bcr": mean(phis),
            "gap_acc_bcr": mean(accs) - mean(phis),
            "acc_ci95_scenario": bootstrap_ci(accs, seed=SEED + hash(rname) % 1000),
            "bcr_ci95_scenario": bootstrap_ci(phis, seed=SEED + 17 + hash(rname) % 1000),
            "by_role_acc": {
                role: mean([1.0 if r["per_role_correct"][role] else 0.0 for r in rows])
                for role in ["current", "historical", "transition", "temporal_order"]
            },
        }

    summary = {
        "config": config,
        "validation": val,
        "scenarios_sha256": sha_bytes(scen_path.read_bytes()),
        "readers": reader_summaries,
        "independent_unit": "scenario",
    }
    (OUT / "transfer_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (OUT / "predictions.jsonl").write_text(
        "\n".join(json.dumps(x, sort_keys=True) for x in predictions_out) + "\n"
    )
    (OUT / "config_freeze.json").write_text(json.dumps(config, indent=2, sort_keys=True) + "\n")
    man = (
        f"{sha_bytes((OUT / 'config_freeze.json').read_bytes())}  config_freeze.json\n"
        f"{sha_bytes(scen_path.read_bytes())}  scenarios.jsonl\n"
        f"{sha_bytes((OUT / 'transfer_summary.json').read_bytes())}  transfer_summary.json\n"
    )
    (OUT / "MANIFEST.sha256").write_text(man)
    print(json.dumps({"validation": val["pass"], "readers": {k: {kk: vv for kk, vv in v.items() if kk in ('mean_acc','bcr','gap_acc_bcr')} for k,v in reader_summaries.items()}}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
