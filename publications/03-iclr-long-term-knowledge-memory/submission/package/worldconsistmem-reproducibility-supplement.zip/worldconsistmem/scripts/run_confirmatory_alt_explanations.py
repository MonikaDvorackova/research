#!/usr/bin/env python3
"""Confirmatory alternative-explanation analyses (read-only vs Option A).

Writes ONLY under results/confirmatory/alt_explanations/.
Does not mutate frozen Option A CSVs/predictions.
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.io_util import read_jsonl  # noqa: E402
from worldconsistmem.metrics import answers_equal, evaluate_bundle  # noqa: E402
from worldconsistmem.models import (  # noqa: E402
    AnswerSchema,
    ConstraintFamily,
    Query,
    QueryBundle,
    QueryFamily,
)
from worldconsistmem.predict import prediction_from_dict  # noqa: E402
from worldconsistmem.scaled_generate import generate_scaled_world  # noqa: E402
from worldconsistmem.stats_world import bootstrap_ci, mean  # noqa: E402

OUT = ROOT / "results" / "confirmatory" / "alt_explanations"
PRED = ROOT / "results" / "scaled" / "predictions"
DATA = ROOT / "data" / "scaled"

SYSTEMS = [
    "B2_latest_only",
    "B3_recency_k3",
    "B4_bm25_k8",
    "H0_ltkm_cap150_ret8",
]

# Preregistered context / size bins (documented before seeing results in this script).
NQUERY_BINS = [(1, 4), (5, 6), (7, 8), (9, 99)]
# Logical-records bins use avg_records_consulted when present in prediction metadata;
# fallback: evidence count proxy from metadata.
RECORD_BINS = [(0, 5), (6, 20), (21, 60), (61, 10_000)]


def sha_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load_bundle_row(row: dict) -> QueryBundle:
    queries = [
        Query(
            query_id=q["query_id"],
            bundle_id=q["bundle_id"],
            family=QueryFamily(q["family"]),
            text=q["text"],
            structured=q.get("structured") or {},
            gold_answer=q["gold_answer"],
            answer_schema=AnswerSchema(q["answer_schema"]),
            target_time=q.get("target_time"),
            target_interval=q.get("target_interval"),
            supporting_event_ids=q.get("supporting_event_ids") or [],
            supporting_provenance_ids=q.get("supporting_provenance_ids") or [],
            applicable_constraints=[
                ConstraintFamily(c) for c in (q.get("applicable_constraints") or [])
            ],
            metadata=q.get("metadata") or {},
        )
        for q in row["queries"]
    ]
    return QueryBundle(
        bundle_id=row["bundle_id"],
        world_id=row["world_id"],
        focal_entities=row.get("focal_entities") or [],
        queries=queries,
        description=row.get("description") or "",
        metadata=row.get("metadata") or {},
    )


def bin_label(bins: list[tuple[int, int]], x: float) -> str:
    xi = int(x)
    for lo, hi in bins:
        if lo <= xi <= hi:
            return f"{lo}-{hi}"
    return "other"


def expected_all_correct_iid(item_correct: list[bool]) -> float:
    """Independence diagnostic: product of empirical Bernoullis with p=observed Acc_i.

    Not a generative model — a diagnostic baseline for conjunction strictness.
    """
    if not item_correct:
        return 1.0
    # Using observed 0/1 as p_i yields product = 1 iff all correct else 0.
    # For a softer baseline use mean Acc^n:
    n = len(item_correct)
    acc = sum(1.0 for c in item_correct if c) / n
    return float(acc**n)


def load_worlds() -> dict[str, Any]:
    index = json.loads((DATA / "world_index.json").read_text())
    worlds = {}
    for row in index:
        wid = row["world_id"]
        # ss0100_000 → seed 100, idx 0, tier small
        tier = row["tier"]
        seed = int(row.get("seed", 100))
        widx = int(row.get("world_idx", int(wid.rsplit("_", 1)[-1])))
        worlds[wid] = generate_scaled_world(seed, widx, tier)
        assert worlds[wid].world_id == wid
    return worlds


def analyze_system(name: str, worlds: dict, bundles: list[QueryBundle]) -> dict[str, Any]:
    pred_path = PRED / f"{name}.jsonl"
    preds = [prediction_from_dict(r) for r in read_jsonl(pred_path)]
    by_bundle: dict[str, list] = defaultdict(list)
    for p in preds:
        by_bundle[p.bundle_id].append(p)

    bundle_rows = []
    for b in bundles:
        plist = by_bundle.get(b.bundle_id)
        if not plist:
            continue
        w = worlds[b.world_id]
        bm = evaluate_bundle(w, b, plist)
        item_correct = [bm.per_query[q.query_id] >= 1.0 for q in b.queries]
        n = len(b.queries)
        acc = bm.mean_query_accuracy
        exp_ac = expected_all_correct_iid(item_correct)  # equals Acc^n with Acc=mean
        # Prefer Acc^n using mean:
        exp_ac = float(acc**n) if n else 1.0
        # records consulted proxy
        recs = []
        for p in plist:
            md = p.metadata or {}
            if "avg_logical_records" in md:
                recs.append(float(md["avg_logical_records"]))
            elif "n_consulted" in md:
                recs.append(float(md["n_consulted"]))
            elif "retrieved_observation_ids" in md:
                recs.append(float(len(md["retrieved_observation_ids"] or [])))
        rec_mean = mean(recs) if recs else float("nan")
        n_abstain = sum(
            1
            for p in plist
            if p.predicted_answer == "__ABSTAIN__"
            or (p.metadata or {}).get("status") == "abstain"
        )
        n_mal = sum(1 for p in plist if (p.metadata or {}).get("malformed"))
        axes = (b.metadata or {}).get("axes") or {}
        bundle_rows.append(
            {
                "bundle_id": b.bundle_id,
                "world_id": b.world_id,
                "tier": (b.metadata or {}).get("tier"),
                "n_queries": n,
                "n_constraints": len(bm.constraint_results),
                "acc": acc,
                "all_correct": bm.all_correct,
                "phi": bm.consistent,
                "expected_all_correct_acc_pow_n": exp_ac,
                "consacc_minus_expected": (1.0 if bm.all_correct else 0.0) - exp_ac,
                "phi_minus_expected_ac": (1.0 if bm.consistent else 0.0) - exp_ac,
                "n_query_bin": bin_label(NQUERY_BINS, n),
                "records_mean": rec_mean,
                "record_bin": bin_label(RECORD_BINS, rec_mean)
                if not math.isnan(rec_mean)
                else "unknown",
                "n_abstain": n_abstain,
                "n_malformed": n_mal,
                "transition_chain_length": axes.get("transition_chain_length"),
                "temporal_distance": axes.get("temporal_distance"),
                "n_constraint_families": axes.get("n_constraint_families"),
            }
        )

    def summarize(rows: list[dict]) -> dict[str, Any]:
        if not rows:
            return {}
        accs = [r["acc"] for r in rows]
        phis = [1.0 if r["phi"] else 0.0 for r in rows]
        cons = [1.0 if r["all_correct"] else 0.0 for r in rows]
        exps = [r["expected_all_correct_acc_pow_n"] for r in rows]
        # world-level BCR for CI
        by_w: dict[str, list[float]] = defaultdict(list)
        for r in rows:
            by_w[r["world_id"]].append(1.0 if r["phi"] else 0.0)
        world_bcr = [mean(v) for v in by_w.values()]
        return {
            "n_bundles": len(rows),
            "n_worlds": len(by_w),
            "mean_acc": mean(accs),
            "bcr": mean(phis),
            "consacc": mean(cons),
            "mean_expected_all_correct": mean(exps),
            "bcr_minus_expected_ac": mean(phis) - mean(exps),
            "consacc_minus_expected_ac": mean(cons) - mean(exps),
            "gap_acc_bcr": mean(accs) - mean(phis),
            "bcr_world_ci95": bootstrap_ci(world_bcr, seed=hash(name) % 10_000),
        }

    by_nq: dict[str, list] = defaultdict(list)
    by_rec: dict[str, list] = defaultdict(list)
    by_tier: dict[str, list] = defaultdict(list)
    by_chain: dict[str, list] = defaultdict(list)
    for r in bundle_rows:
        by_nq[r["n_query_bin"]].append(r)
        by_rec[r["record_bin"]].append(r)
        by_tier[str(r["tier"])].append(r)
        by_chain[str(r["transition_chain_length"])].append(r)

    # Abstention decomposition (descriptive): bundles with any abstain vs none
    with_abs = [r for r in bundle_rows if r["n_abstain"] > 0]
    no_abs = [r for r in bundle_rows if r["n_abstain"] == 0]

    return {
        "system": name,
        "prediction_sha256": sha_file(pred_path),
        "overall": summarize(bundle_rows),
        "by_n_queries": {k: summarize(v) for k, v in sorted(by_nq.items())},
        "by_record_bin": {k: summarize(v) for k, v in sorted(by_rec.items())},
        "by_tier": {k: summarize(v) for k, v in sorted(by_tier.items())},
        "by_transition_chain": {k: summarize(v) for k, v in sorted(by_chain.items())},
        "abstention_split": {
            "with_abstention": summarize(with_abs),
            "no_abstention": summarize(no_abs),
        },
        "preregistered_bins": {
            "n_query_bins": NQUERY_BINS,
            "record_bins": RECORD_BINS,
            "independence_note": (
                "expected_all_correct = Acc^n per bundle (i.i.d. diagnostic). "
                "Not a claim that errors are independent."
            ),
        },
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    print("Loading worlds…", flush=True)
    worlds = load_worlds()
    print(f"worlds={len(worlds)}", flush=True)
    bundles = [load_bundle_row(r) for r in read_jsonl(DATA / "bundles.jsonl")]
    print(f"bundles={len(bundles)}", flush=True)

    results = []
    for name in SYSTEMS:
        print(f"Analyzing {name}…", flush=True)
        results.append(analyze_system(name, worlds, bundles))

    manifest = {
        "label": "confirmatory_alt_explanations",
        "not_option_a": True,
        "systems": SYSTEMS,
        "bundles_sha256": sha_file(DATA / "bundles.jsonl"),
        "manifest_sha256": sha_file(DATA / "manifest.json"),
        "results": results,
    }
    out = OUT / "alt_explanations_summary.json"
    out.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    (OUT / "MANIFEST.sha256").write_text(
        f"{sha_file(out)}  alt_explanations_summary.json\n"
    )
    print("Wrote", out)
    # Print headline
    for r in results:
        o = r["overall"]
        print(
            r["system"],
            "Acc",
            round(o["mean_acc"], 4),
            "BCR",
            round(o["bcr"], 4),
            "ConsAcc",
            round(o["consacc"], 4),
            "E[Acc^n]",
            round(o["mean_expected_all_correct"], 4),
            "BCR-E",
            round(o["bcr_minus_expected_ac"], 4),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
