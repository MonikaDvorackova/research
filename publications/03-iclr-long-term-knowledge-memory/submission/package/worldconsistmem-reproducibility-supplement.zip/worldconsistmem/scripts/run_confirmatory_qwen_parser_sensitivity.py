#!/usr/bin/env python3
"""Confirmatory Qwen parser-sensitivity (no re-inference; no Option A mutation).

Re-parse frozen run2 raw_output under alternate JSON extractors and rescore Acc/BCR
on the H4 bundle set. Labelled confirmatory under results/confirmatory/readers/.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.io_util import read_jsonl  # noqa: E402
from worldconsistmem.metrics import evaluate_bundle  # noqa: E402
from worldconsistmem.models import (  # noqa: E402
    AnswerSchema,
    ConstraintFamily,
    Prediction,
    Query,
    QueryBundle,
    QueryFamily,
)
from worldconsistmem.scaled_generate import generate_scaled_world  # noqa: E402
from worldconsistmem.stats_world import bootstrap_ci, mean  # noqa: E402

OUT = ROOT / "results" / "confirmatory" / "readers"
CACHE = ROOT / "results" / "scaled" / "run2" / "llm_reader_cache" / "Qwen2.5-3B-Instruct-4bit.jsonl"
DATA = ROOT / "data" / "scaled"
ABSTAIN = "__ABSTAIN__"

# Systems present in run2 cache
SYSTEMS = ["B1_flat_cap150_compact", "B3_recency_k8", "B4_bm25_k8", "H0_ltkm_cap150_ret8"]


def sha_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def parse_strict_json(raw: str) -> tuple[Any, str]:
    """Original-style: first {...} JSON object."""
    if not raw:
        return None, "empty"
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return None, "no_object"
    try:
        obj = json.loads(m.group(0))
        return obj, "ok"
    except Exception:
        return None, "json_fail"


def parse_relaxed_json(raw: str) -> tuple[Any, str]:
    """Allow single quotes / trailing commas lightly; fall back to strict."""
    obj, st = parse_strict_json(raw)
    if st == "ok":
        return obj, st
    if not raw:
        return None, "empty"
    txt = raw.strip()
    txt = txt.replace("'", '"')
    txt = re.sub(r",\s*}", "}", txt)
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        return None, "no_object"
    try:
        return json.loads(m.group(0)), "relaxed_ok"
    except Exception:
        return None, "json_fail"


def parse_answer_field_regex(raw: str) -> tuple[Any, str]:
    """Semantically equivalent extraction focusing on answer/abstain fields."""
    if not raw:
        return None, "empty"
    if re.search(r'"abstain"\s*:\s*true', raw, re.I) or re.search(r"abstain\"?\s*:\s*true", raw, re.I):
        return {"answer": None, "abstain": True}, "abstain_field"
    m = re.search(r'"answer"\s*:\s*(".*?"|null|true|false|-?\d+(?:\.\d+)?)', raw)
    if not m:
        obj, st = parse_strict_json(raw)
        return obj, st
    try:
        ans = json.loads(m.group(1))
        return {"answer": ans, "abstain": False}, "answer_field"
    except Exception:
        return None, "answer_parse_fail"


PARSERS = {
    "strict_json": parse_strict_json,
    "relaxed_json": parse_relaxed_json,
    "answer_field_regex": parse_answer_field_regex,
}


def obj_to_answer(obj: Any) -> tuple[Any, str]:
    if obj is None:
        return ABSTAIN, "malformed"
    if isinstance(obj, dict):
        if obj.get("abstain") is True or obj.get("answer") is None:
            return ABSTAIN, "abstain"
        return obj.get("answer"), "ok"
    return ABSTAIN, "malformed"


def load_bundle_map() -> dict[str, QueryBundle]:
    out = {}
    for row in read_jsonl(DATA / "bundles.jsonl"):
        queries = [
            Query(
                query_id=q["query_id"],
                bundle_id=q["bundle_id"],
                family=QueryFamily(q["family"]),
                text=q["text"],
                structured=q.get("structured") or {},
                gold_answer=q["gold_answer"],
                answer_schema=AnswerSchema(q["answer_schema"]),
                target_time=q.get("target_time"),
                target_interval=q.get("target_interval"),
                supporting_event_ids=q.get("supporting_event_ids") or [],
                supporting_provenance_ids=q.get("supporting_provenance_ids") or [],
                applicable_constraints=[
                    ConstraintFamily(c) for c in (q.get("applicable_constraints") or [])
                ],
                metadata=q.get("metadata") or {},
            )
            for q in row["queries"]
        ]
        out[row["bundle_id"]] = QueryBundle(
            bundle_id=row["bundle_id"],
            world_id=row["world_id"],
            focal_entities=row.get("focal_entities") or [],
            queries=queries,
            description=row.get("description") or "",
            metadata=row.get("metadata") or {},
        )
    return out


def load_h4_worlds(bundle_map: dict[str, QueryBundle], bundle_ids: set[str]) -> dict[str, Any]:
    need = {bundle_map[b].world_id for b in bundle_ids if b in bundle_map}
    index = json.loads((DATA / "world_index.json").read_text())
    worlds = {}
    for row in index:
        if row["world_id"] in need:
            worlds[row["world_id"]] = generate_scaled_world(
                int(row.get("seed", 100)), int(row.get("world_idx", int(row["world_id"].rsplit("_", 1)[-1]))), row["tier"]
            )
    return worlds


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    if not CACHE.exists():
        print("Qwen cache missing", CACHE)
        return 1
    rows = [json.loads(l) for l in CACHE.open() if l.strip()]
    # Keep last row per (system, query_id)
    latest: dict[tuple[str, str], dict] = {}
    for r in rows:
        latest[(r["memory_system"], r["query_id"])] = r

    bundle_map = load_bundle_map()
    # Infer H4 bundles from cache query ids
    qids = {qid for _, qid in latest}
    bundle_ids = {qid.rsplit(":", 1)[0] if qid.count(":") >= 3 else qid for qid in qids}
    # query_id format ss0100_000:b:ceo:0:current → bundle ss0100_000:b:ceo:0
    bundle_ids = set()
    for qid in qids:
        parts = qid.split(":")
        # world:b:kind:idx:slot → bundle = first 4 colon parts if b present
        if len(parts) >= 5 and parts[1] == "b":
            bundle_ids.add(":".join(parts[:4]))
        else:
            # fallback: drop last
            bundle_ids.add(qid.rsplit(":", 1)[0])

    worlds = load_h4_worlds(bundle_map, bundle_ids)
    print(f"cache_rows={len(rows)} unique={len(latest)} bundles={len(bundle_ids)} worlds={len(worlds)}")

    summary = {
        "label": "confirmatory_qwen_parser_sensitivity",
        "not_option_a": True,
        "model_id": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "cache_sha256": sha_file(CACHE),
        "note": "No re-inference; parsers applied to frozen raw_output only.",
        "parsers": {},
    }

    for pname, pfn in PARSERS.items():
        by_sys: dict[str, Any] = {}
        for sys in SYSTEMS:
            # Build predictions for bundles that have complete query coverage in cache for this system
            preds_by_bundle: dict[str, list[Prediction]] = defaultdict(list)
            n_mal = n_abs = n_ok = 0
            for (ms, qid), r in latest.items():
                if ms != sys:
                    continue
                obj, st = pfn(r.get("raw_output") or "")
                ans, status = obj_to_answer(obj)
                if status == "malformed":
                    n_mal += 1
                elif status == "abstain":
                    n_abs += 1
                else:
                    n_ok += 1
                # bundle id
                parts = qid.split(":")
                bid = ":".join(parts[:4]) if len(parts) >= 5 and parts[1] == "b" else qid.rsplit(":", 1)[0]
                preds_by_bundle[bid].append(
                    Prediction(
                        bundle_id=bid,
                        query_id=qid,
                        predicted_answer=ans,
                        predicted_provenance=None,
                        system_id=f"qwen_parser:{pname}|{sys}",
                        run_id="confirmatory_parser",
                        metadata={"status": status, "parse_status": st},
                    )
                )
            # Evaluate complete bundles only
            brows = []
            for bid, plist in preds_by_bundle.items():
                b = bundle_map.get(bid)
                if not b or b.world_id not in worlds:
                    continue
                if len(plist) != len(b.queries):
                    continue
                bm = evaluate_bundle(worlds[b.world_id], b, plist)
                brows.append(bm)
            if not brows:
                by_sys[sys] = {"n_bundles": 0}
                continue
            acc = mean([m.mean_query_accuracy for m in brows])
            bcr = mean([1.0 if m.consistent else 0.0 for m in brows])
            by_w: dict[str, list[float]] = defaultdict(list)
            for m in brows:
                by_w[m.world_id].append(1.0 if m.consistent else 0.0)
            world_bcr = [mean(v) for v in by_w.values()]
            by_sys[sys] = {
                "n_bundles": len(brows),
                "mean_acc": acc,
                "bcr": bcr,
                "gap_acc_bcr": acc - bcr,
                "abstention_rate": n_abs / max(1, n_ok + n_abs + n_mal),
                "malformed_rate": n_mal / max(1, n_ok + n_abs + n_mal),
                "bcr_world_ci95": bootstrap_ci(world_bcr, seed=hash(pname + sys) % 10_000),
            }
        summary["parsers"][pname] = by_sys

    out = OUT / "qwen_parser_sensitivity.json"
    out.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    (OUT / "MANIFEST.sha256").write_text(f"{sha_file(out)}  qwen_parser_sensitivity.json\n")
    # Blocker note for Phi
    (OUT / "PHI_BLOCKER.json").write_text(
        json.dumps(
            {
                "requested": "mlx-community/Phi-3.5-mini-instruct-4bit confirmatory H4",
                "blocked": True,
                "reasons": [
                    "mlx and mlx_lm not importable in current Python",
                    "no local HF weight cache for Phi/Qwen safetensors",
                    "disk free ~4GB insufficient for safe re-download without authorization",
                    "existing Phi cache only 22 incomplete smoke rows",
                    "no API credentials configured",
                ],
            },
            indent=2,
        )
        + "\n"
    )
    print("Wrote", out)
    for pname, by_sys in summary["parsers"].items():
        for sys, s in by_sys.items():
            if s.get("n_bundles"):
                print(pname, sys, "Acc", round(s["mean_acc"], 4), "BCR", round(s["bcr"], 4), "n", s["n_bundles"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
