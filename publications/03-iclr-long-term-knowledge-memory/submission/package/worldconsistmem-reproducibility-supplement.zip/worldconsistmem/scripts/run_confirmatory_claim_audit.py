#!/usr/bin/env python3
"""Audit + conjunction diagnostic + Qwen failure sample for confirmatory studies.

Writes under results/confirmatory/ — does not mutate Option A or frozen scenarios.
"""

from __future__ import annotations

import hashlib
import json
import random
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.stats_world import bootstrap_ci, mean  # noqa: E402

NTL = ROOT / "results" / "confirmatory" / "naturalistic_transfer"
READERS = ROOT / "results" / "confirmatory" / "readers"
CACHE = ROOT / "results" / "scaled" / "run2" / "llm_reader_cache" / "Qwen2.5-3B-Instruct-4bit.jsonl"
OUT = NTL / "analysis"
SAMPLE_SEED = 20260908


def sha_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def expected_complete_role_product(role_acc: dict[str, float], roles: list[str]) -> float:
    p = 1.0
    for r in roles:
        p *= float(role_acc.get(r, 0.0))
    return p


def expected_complete_p_pow_m(p: float, m: int) -> float:
    return float(p**m)


def analyze_transfer() -> dict[str, Any]:
    summary = json.loads((NTL / "transfer_summary.json").read_text())
    preds = [json.loads(l) for l in (NTL / "predictions.jsonl").open() if l.strip()]
    scenarios = [json.loads(l) for l in (NTL / "scenarios.jsonl").open() if l.strip()]
    n_scen = len(scenarios)
    q_per = len(scenarios[0]["queries"]) if scenarios else 0
    roles = ["current", "historical", "transition", "temporal_order"]

    by_reader: dict[str, Any] = {}
    for rname, rs in summary["readers"].items():
        rpreds = [p for p in preds if p["reader"] == rname]
        # correct-query counts per scenario
        # reconstruct from predictions.jsonl structure: pred has acc, phi
        # Need per-role from transfer_summary by_role_acc only at aggregate; load score from preds
        # predictions only store acc/phi/pred — recompute role correctness vs gold
        scen_map = {s["scenario_id"]: s for s in scenarios}
        correct_counts = []
        phi_flags = []
        role_hits = {r: [] for r in roles}
        for p in rpreds:
            s = scen_map[p["scenario_id"]]
            gold = s["gold"]
            pred = p["pred"]
            n_ok = 0
            for role in roles:
                ok = pred.get(role) == gold.get(role)
                # structured transition dict compare
                if role == "transition":
                    ok = pred.get(role) == gold.get(role)
                role_hits[role].append(1.0 if ok else 0.0)
                if ok:
                    n_ok += 1
            correct_counts.append(n_ok)
            phi_flags.append(1.0 if p["phi"] else 0.0)

        p_bar = rs["mean_acc"]
        m = q_per
        exp_pow = expected_complete_p_pow_m(p_bar, m)
        role_acc = {r: mean(role_hits[r]) for r in roles}
        exp_role = expected_complete_role_product(role_acc, roles)
        obs_bcr = rs["bcr"]

        by_reader[rname] = {
            "definition": {
                "gold": "oracle: emits scenario gold answers",
                "last_event_heuristic": "uses only last narrative sentence; recovers current-like entity; abstains on hist/transition/temporal",
                "entity_prior": "shortcut: prefers P1/LOC1 as current and collapses hist=current",
                "narrative_heuristic": "regex/from-to extraction over full narrative",
            }.get(rname, rname),
            "n_scenarios": n_scen,
            "queries_per_scenario": m,
            "total_queries": n_scen * m,
            "mean_acc": rs["mean_acc"],
            "bcr": obs_bcr,
            "gap_acc_bcr": rs["gap_acc_bcr"],
            "acc_ci95_scenario": rs["acc_ci95_scenario"],
            "bcr_ci95_scenario": rs["bcr_ci95_scenario"],
            "by_role_acc": role_acc,
            "frac_bcr1": mean(phi_flags),  # same as bcr when phi in {0,1}
            "frac_bcr0": 1.0 - mean(phi_flags),
            "correct_query_count_hist": dict(Counter(correct_counts)),
            "conjunction_diagnostic": {
                "m": m,
                "p_mean_acc": p_bar,
                "expected_complete_p_pow_m": exp_pow,
                "expected_complete_role_product": exp_role,
                "observed_bcr": obs_bcr,
                "observed_minus_p_pow_m": obs_bcr - exp_pow,
                "observed_minus_role_product": obs_bcr - exp_role,
                "note": "Diagnostic reference only; not a causal model or BCR replacement.",
                "interpretation_hint": (
                    "close_to_reference"
                    if abs(obs_bcr - exp_role) <= 0.05
                    else (
                        "below_reference_correlated_or_dependency"
                        if obs_bcr < exp_role - 0.05
                        else "above_reference"
                    )
                ),
            },
            "supports_central_divergence": bool(
                rs["mean_acc"] >= 0.5 and (rs["mean_acc"] - obs_bcr) >= 0.15
            ),
            "classification": (
                "central_divergence_support"
                if rs["mean_acc"] >= 0.5 and (rs["mean_acc"] - obs_bcr) >= 0.15
                else (
                    "solvability_control"
                    if rname == "gold"
                    else (
                        "heuristic_difficulty_probe"
                        if rs["mean_acc"] < 0.5
                        else "high_acc_high_bcr_or_negative_gap"
                    )
                )
            ),
        }

    return {
        "n_independent_scenarios": n_scen,
        "queries_per_scenario": q_per,
        "total_evaluated_queries": n_scen * q_per,
        "scenarios_sha256": summary["scenarios_sha256"],
        "readers": by_reader,
        "verdict": (
            "Naturalistic transfer currently demonstrates solvability (gold) and inadequacy of "
            "crude heuristics (last-event/entity-prior with low Acc). It does NOT demonstrate "
            "central Acc–BCR divergence under a meaningful-Acc reader: no LLM was evaluated on "
            "these scenarios; narrative_heuristic has Acc=0.875 with BCR=1.0."
        ),
    }


def parse_variants(raw: str) -> dict[str, Any]:
    def strict(raw: str):
        m = re.search(r"\{.*\}", raw or "", re.S)
        if not m:
            return None, "no_object"
        try:
            return json.loads(m.group(0)), "ok"
        except Exception:
            return None, "json_fail"

    def relaxed(raw: str):
        obj, st = strict(raw)
        if st == "ok":
            return obj, st
        txt = (raw or "").strip().replace("'", '"')
        txt = re.sub(r",\s*}", "}", txt)
        m = re.search(r"\{.*\}", txt, re.S)
        if not m:
            return None, "no_object"
        try:
            return json.loads(m.group(0)), "relaxed_ok"
        except Exception:
            return None, "json_fail"

    def field(raw: str):
        if not raw:
            return None, "empty"
        if re.search(r'"abstain"\s*:\s*true', raw, re.I):
            return {"answer": None, "abstain": True}, "abstain_field"
        m = re.search(r'"answer"\s*:\s*(".*?"|null|true|false|-?\d+(?:\.\d+)?)', raw)
        if not m:
            return strict(raw)
        try:
            return {"answer": json.loads(m.group(1)), "abstain": False}, "answer_field"
        except Exception:
            return None, "answer_parse_fail"

    return {
        "strict_json": strict(raw),
        "relaxed_json": relaxed(raw),
        "answer_field_regex": field(raw),
    }


def classify_row(r: dict) -> str:
    st = r.get("status")
    if st == "malformed" or r.get("malformed"):
        return "malformed_response"
    if st == "abstain" or r.get("predicted_answer") == "__ABSTAIN__":
        return "explicit_abstention"
    if r.get("predicted_answer") is None:
        return "missing_response"
    return "substantive_or_unchecked"  # correctness needs gold; treated as non-artefact channel


def qwen_error_decomposition_and_sample() -> dict[str, Any]:
    rows = [json.loads(l) for l in CACHE.open() if l.strip()]
    # last per (system, query)
    latest = {}
    for r in rows:
        latest[(r["memory_system"], r["query_id"])] = r
    rows = list(latest.values())

    decomp = Counter(classify_row(r) for r in rows)
    # parser agreement on sample of failures (abstain+malformed+ok)
    rng = random.Random(SAMPLE_SEED)
    # focus H0 system failures / all statuses for inspection
    h0 = [r for r in rows if r["memory_system"] == "H0_ltkm_cap150_ret8"]
    # preregistered: sample 12 rows stratified by status
    by_st = defaultdict(list)
    for r in h0:
        by_st[classify_row(r)].append(r)
    sample = []
    for st, bucket in sorted(by_st.items()):
        take = min(4, len(bucket))
        sample.extend(rng.sample(bucket, take) if len(bucket) >= take else bucket)
    sample = sample[:12]

    inspected = []
    parser_disagree = 0
    for r in sample:
        variants = parse_variants(r.get("raw_output") or "")

        def to_ans(obj_st):
            obj, st = obj_st
            if obj is None:
                return "__ABSTAIN__", "malformed", st
            if isinstance(obj, dict) and (obj.get("abstain") is True or obj.get("answer") is None):
                return "__ABSTAIN__", "abstain", st
            if isinstance(obj, dict):
                return obj.get("answer"), "ok", st
            return "__ABSTAIN__", "malformed", st

        parsed = {k: to_ans(v) for k, v in variants.items()}
        answers = {k: v[0] for k, v in parsed.items()}
        disagree = len(set(json.dumps(a, sort_keys=True) if isinstance(a, (dict, list)) else str(a) for a in answers.values())) > 1
        if disagree:
            parser_disagree += 1
        inspected.append(
            {
                "scenario_or_query_id": r["query_id"],
                "bundle_id": r.get("bundle_id"),
                "memory_system": r["memory_system"],
                "raw_output": (r.get("raw_output") or "")[:500],
                "cached_predicted_answer": r.get("predicted_answer"),
                "cached_status": r.get("status"),
                "parsers": {
                    k: {"answer": v[0], "class": v[1], "parse_status": v[2]} for k, v in parsed.items()
                },
                "parser_agreement": not disagree,
                "final_classification": classify_row(r),
            }
        )

    parser_summary = json.loads((READERS / "qwen_parser_sensitivity.json").read_text())
    # Acc/BCR table
    acc_bcr = {}
    for pname, by_sys in parser_summary["parsers"].items():
        acc_bcr[pname] = {}
        for sys, s in by_sys.items():
            if not s.get("n_bundles"):
                continue
            acc_bcr[pname][sys] = {
                "mean_acc": s["mean_acc"],
                "bcr": s["bcr"],
                "gap_acc_bcr": s["gap_acc_bcr"],
                "abstention_rate": s["abstention_rate"],
                "malformed_rate": s["malformed_rate"],
                "n_bundles": s["n_bundles"],
                "supports_central_divergence": bool(s["mean_acc"] >= 0.5 and s["gap_acc_bcr"] >= 0.15),
                "classification": (
                    "low_acc_difficulty_floor_with_bcr0"
                    if s["mean_acc"] < 0.5 and s["bcr"] == 0.0
                    else "central_divergence_candidate"
                ),
            }

    return {
        "model_id": "mlx-community/Qwen2.5-3B-Instruct-4bit",
        "evaluation_object": "H4 symbolic evidence packs (NOT naturalistic transfer scenarios)",
        "n_cache_rows_unique": len(rows),
        "error_decomposition_counts": dict(decomp),
        "error_decomposition_rates": {k: v / len(rows) for k, v in decomp.items()},
        "parser_acc_bcr": acc_bcr,
        "manual_inspection": {
            "sample_seed": SAMPLE_SEED,
            "n_inspected": len(inspected),
            "parser_disagree_n": parser_disagree,
            "rows": inspected,
        },
        "verdict": (
            "Qwen H0 Acc≈0.187 with BCR=0 under all parsers: zero BCR is not a single-parser artefact, "
            "but item Acc is low, so this primarily supports a difficulty/floor probe plus parser robustness, "
            "not high-Acc/low-BCR divergence for the LLM reader."
        ),
    }


def stronger_reader_blocker() -> dict[str, Any]:
    return {
        "requested": "stronger reader on all 36 naturalistic scenarios",
        "ran": False,
        "blockers": [
            "mlx/mlx_lm not importable",
            "no local HF safetensor cache for Phi/Qwen",
            "disk free ~4GB; large weight download not authorized",
            "no OpenAI/Anthropic/Together/Groq/OpenRouter API keys in environment",
            "ollama not installed",
        ],
        "if_paid_api_were_authorized": {
            "proposed_model": "openai/gpt-4o-mini (example; not executed)",
            "n_calls": 36 * 4,
            "est_input_tokens": 36 * 4 * 450,
            "est_output_tokens": 36 * 4 * 40,
            "est_total_cost_usd": 0.05,
            "expected_runtime_min": 10,
            "note": "Stopped before execution per authorization rule.",
        },
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    transfer = analyze_transfer()
    qwen = qwen_error_decomposition_and_sample()
    blocker = stronger_reader_blocker()
    report = {
        "label": "confirmatory_claim_audit",
        "not_option_a": True,
        "naturalistic_transfer": transfer,
        "qwen_h4_parser_study": qwen,
        "stronger_naturalistic_reader": blocker,
        "answers_to_readiness_questions": {
            "q1_transfer_divergence_or_difficulty": (
                "difficulty/validity probe + solvability control; NOT central Acc–BCR divergence "
                "(no meaningful-Acc reader with low BCR on the 36 scenarios)"
            ),
            "q2_persists_for_stronger_reader": "unknown; stronger reader not runnable",
            "q3_parser_explains_qwen_bcr0": (
                "No: three parsers agree on BCR=0; Acc remains low (~0.09–0.19), so not high-Acc divergence"
            ),
            "q4_conjunction_explains_gap": (
                "On frozen symbolic B4/H0, BCR sits below Acc^n (residual). On transfer heuristics with low Acc, "
                "p^m is near 0 so BCR=0 is consistent with conjunction under low p; sample supports difficulty more than dependency."
            ),
            "q5_strongest_remaining_rejection": (
                "No meaningful-Acc LLM/naturalistic reader confirming Acc–BCR divergence beyond the frozen symbolic study"
            ),
        },
    }
    out = OUT / "claim_audit_report.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    (OUT / "MANIFEST.sha256").write_text(f"{sha_file(out)}  claim_audit_report.json\n")
    print(json.dumps({
        "wrote": str(out),
        "transfer_verdict": transfer["verdict"],
        "qwen_verdict": qwen["verdict"],
        "readiness": report["answers_to_readiness_questions"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
