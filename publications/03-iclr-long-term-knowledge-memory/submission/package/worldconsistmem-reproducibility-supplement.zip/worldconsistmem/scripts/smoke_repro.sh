#!/usr/bin/env bash
# Fast smoke reproduction for the anonymized WorldConsistMem package.
# Does NOT rerun full Option A scaled symbolic (hours) or Qwen H4 LLM inference.
#
# Note: a disk-constrained clean clone may omit results/scaled/predictions/*.jsonl;
# those files are not required for tests, checksum verification of CSVs, or NEW symbolic runs.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONPATH=src
export TMPDIR="${TMPDIR:-$ROOT/.tmp}"
mkdir -p "$TMPDIR"

echo "[smoke] root=$ROOT"
echo "[smoke] python=$(python3 -V 2>&1)"
echo "[smoke] start=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
START=$(date +%s)

if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate

if ! python -c "import yaml, pytest" 2>/dev/null; then
  python -m pip install -q -r requirements.txt || {
    echo "[smoke] FAIL: cannot install PyYAML/pytest" >&2
    exit 1
  }
fi

python -m pytest tests/ -q
python scripts/verify_frozen_checksums.py
python scripts/run_new_analyses.py gold
python scripts/run_new_analyses.py budget
python scripts/run_new_analyses.py shortcuts
python scripts/run_new_analyses.py ablations-reprint

python << 'PY'
import json
from pathlib import Path
root = Path('.')
gold = json.loads((root/'results/new/rescue_p1/h4_gold_sanity.json').read_text())
assert gold['metrics']['mean_query_accuracy'] == 1.0
assert gold['metrics']['bcr'] == 1.0
assert gold['n_violations'] == 0
budget = json.loads((root/'results/new/rescue_p3/retrieval_budget_sensitivity.json').read_text())
by = {r['system']: r for r in budget['rows']}
assert by['B2_latest_only']['Acc'] == by['B3_recency_k3']['Acc'] == 0.4905
assert by['B2_latest_only']['BCR'] == 0.2188
assert by['B3_recency_k3']['BCR'] == 0.0
short = json.loads((root/'results/new/rescue_p2/shortcut_baselines.json').read_text())
assert short['empty']['mean_query_accuracy'] == 0.0
assert short['family_majority']['bcr'] == 0.0
assert short['gold']['bcr'] == 1.0
print('NEW smoke asserts: PASS')
PY

END=$(date +%s)
echo "[smoke] end=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "[smoke] runtime_sec=$((END-START))"
echo "[smoke] PASS"
