#!/usr/bin/env python3
"""Export CSV slices used by manuscript figures/tables (data only; not artwork)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "data_exports"


def copy_cols(src: Path, dst: Path, cols: list[str] | None = None) -> None:
    rows = list(csv.DictReader(src.open()))
    if not rows:
        dst.write_text("")
        return
    fieldnames = cols or list(rows[0].keys())
    with dst.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fieldnames})


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    copy_cols(
        ROOT / "results/scaled/system_results.csv",
        OUT / "fig3_tab_symbolic_system_results.csv",
        [
            "system",
            "mean_query_accuracy",
            "bcr",
            "gap_query",
            "bcr_world_ci95_lo",
            "bcr_world_ci95_hi",
        ],
    )
    # CSR if present
    pcs = ROOT / "results/scaled/partial_consistency_results.csv"
    if pcs.exists():
        copy_cols(pcs, OUT / "fig3_partial_consistency_results.csv")
    copy_cols(
        ROOT / "results/scaled/constraint_family_results.csv",
        OUT / "fig4_constraint_family_results.csv",
    )
    copy_cols(
        ROOT / "results/scaled/difficulty_results.csv",
        OUT / "fig5_difficulty_results.csv",
    )
    copy_cols(ROOT / "results/corruption_metrics.csv", OUT / "tab_corruption.csv")
    copy_cols(ROOT / "results/scaled/ablation_results.csv", OUT / "tab_ablations.csv")
    qwen = ROOT / "results/scaled/run2/qwen_system_results.csv"
    if qwen.exists():
        copy_cols(qwen, OUT / "tab_qwen_system_results.csv")

    # NEW summaries
    for rel in [
        "results/new/rescue_p3/retrieval_budget_sensitivity.json",
        "results/new/rescue_p2/rescue_p2_robustness.json",
        "results/new/rescue_p1/h4_gold_sanity.json",
    ]:
        p = ROOT / rel
        if p.exists():
            (OUT / p.name).write_text(p.read_text())

    manifest = {
        "note": "Data exports for manuscript figures/tables. Static PDFs are not regenerated here.",
        "files": sorted(x.name for x in OUT.iterdir()),
    }
    (OUT / "README.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print("wrote", OUT)


if __name__ == "__main__":
    main()
