#!/usr/bin/env python3
"""Labelled NEW analyses for WorldConsistMem (not Option A freeze).

Subcommands reproduce expected artefacts under results/new/.
Does not write into results/scaled/ Option A tables.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import time
from collections import Counter, defaultdict
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
import sys

sys.path.insert(0, str(ROOT / "src"))

from worldconsistmem.baselines.adapters import (  # noqa: E402
    BM25RetrievalMemory,
    LatestStateMemory,
    RecencyWeightedMemory,
)
from worldconsistmem.evaluate import evaluate_predictions  # noqa: E402
from worldconsistmem.models import Prediction  # noqa: E402
from worldconsistmem.observe import generate_observations  # noqa: E402
from worldconsistmem.scaled_generate import TIERS, generate_scaled_dataset, generate_scaled_world  # noqa: E402
from worldconsistmem.scaled_queries import generate_scaled_bundles  # noqa: E402
from worldconsistmem.stats_world import bootstrap_ci  # noqa: E402

OUT_P1 = ROOT / "results" / "new" / "rescue_p1"
OUT_P2 = ROOT / "results" / "new" / "rescue_p2"
OUT_P3 = ROOT / "results" / "new" / "rescue_p3"


def agg_dict(agg) -> dict:
    d = agg.to_dict()
    return {
        "mean_query_accuracy": round(float(d["mean_query_accuracy"]), 4),
        "bcr": round(float(d["bcr"]), 4),
        "gap_query": round(float(d["mean_query_accuracy"]) - float(d["bcr"]), 4),
        "consacc_strict": round(float(d["consacc_strict"]), 4),
    }


def protocol_worlds(seed: int, wpt: int = 6, density_override=None, tiers=("small", "medium", "large")):
    worlds = []
    idx = 0
    for tier in tiers:
        old = TIERS[tier]
        if density_override is not None:
            TIERS[tier] = replace(old, relation_density=float(density_override))
        try:
            for i in range(wpt):
                worlds.append(generate_scaled_world(seed + idx, i, tier=tier))
                idx += 1
        finally:
            TIERS[tier] = old
    return worlds


def run_adapter(adapter, world_list, bundles, obs_by_world):
    worlds = {w.world_id: w for w in world_list}
    by_w = defaultdict(list)
    for b in bundles:
        by_w[b.world_id].append(b)
    preds = []
    for wid, blist in by_w.items():
        adapter.reset()
        for o in obs_by_world[wid]:
            adapter.ingest(o)
        for b in blist:
            preds.extend(adapter.answer_bundle(b))
    bms, agg, viols = evaluate_predictions(worlds, bundles, preds, relaxed_acc_threshold=0.8)
    return bms, agg, viols


def world_cis(bms, bundles, world_list):
    bm_by = {m.bundle_id: m for m in bms}
    world_acc, world_bcr = [], []
    for w in world_list:
        wb = [b for b in bundles if b.world_id == w.world_id]
        if not wb:
            continue
        accs = [bm_by[b.bundle_id].mean_query_accuracy for b in wb]
        bcrs = [1.0 if bm_by[b.bundle_id].consistent else 0.0 for b in wb]
        world_acc.append(sum(accs) / len(accs))
        world_bcr.append(sum(bcrs) / len(bcrs))
    ca = bootstrap_ci(world_acc, seed=7)
    cb = bootstrap_ci(world_bcr, seed=7)
    return {
        "acc_world_mean": round(ca["mean"], 4),
        "acc_world_ci95": [round(ca["lo"], 4), round(ca["hi"], 4)],
        "bcr_world_mean": round(cb["mean"], 4),
        "bcr_world_ci95": [round(cb["lo"], 4), round(cb["hi"], 4)],
    }


def run_b3_b4(world_list, bundles, obs_by_world, run_id: str):
    out = {}
    for name, factory in [
        ("B3_recency_k8", lambda: RecencyWeightedMemory(k=8, recency_coef=0.15, run_id=run_id)),
        ("B4_bm25_k8", lambda: BM25RetrievalMemory(k=8, run_id=run_id)),
    ]:
        bms, agg, _ = run_adapter(factory(), world_list, bundles, obs_by_world)
        row = agg_dict(agg)
        row.update(world_cis(bms, bundles, world_list))
        row.update(
            {
                "n_worlds": len(world_list),
                "n_bundles": len(bundles),
                "n_queries": sum(len(b.queries) for b in bundles),
            }
        )
        out[name] = row
    return out


def cmd_gold(_args):
    OUT_P1.mkdir(parents=True, exist_ok=True)
    world_list = generate_scaled_dataset(seed=100, worlds_per_tier=34)
    by_tier = {"small": [], "medium": [], "large": []}
    for w in world_list:
        by_tier[w.meta["tier"]].append(w)
    h4_list = []
    for t in ("small", "medium", "large"):
        h4_list.extend(by_tier[t][:6])
    worlds = {w.world_id: w for w in h4_list}
    bundles = []
    for w in h4_list:
        bundles.extend(generate_scaled_bundles(w))
    preds = [
        Prediction(
            bundle_id=b.bundle_id,
            query_id=q.query_id,
            predicted_answer=q.gold_answer,
            system_id="gold",
            run_id="rescue_p1_h4_gold_sanity",
            metadata={"source": "gold"},
        )
        for b in bundles
        for q in b.queries
    ]
    bms, agg, viols = evaluate_predictions(worlds, bundles, preds, relaxed_acc_threshold=0.8)
    d = agg.to_dict()
    payload = {
        "experiment_id": "rescue_p1_h4_gold_sanity",
        "label": "NEW — not part of Option A freeze",
        "n_worlds": 18,
        "n_bundles": len(bundles),
        "n_queries": sum(len(b.queries) for b in bundles),
        "metrics": d,
        "n_violations": len(viols),
    }
    (OUT_P1 / "h4_gold_sanity.json").write_text(json.dumps(payload, indent=2, default=str))
    print("gold Acc", d.get("mean_query_accuracy"), "BCR", d.get("bcr"), "viol", len(viols))


def cmd_seeds(_args):
    OUT_P1.mkdir(parents=True, exist_ok=True)
    OUT_P2.mkdir(parents=True, exist_ok=True)
    rows = []
    for seed in range(100, 106):
        t0 = time.time()
        wl = protocol_worlds(seed, wpt=6)
        bundles = []
        for w in wl:
            bundles.extend(generate_scaled_bundles(w))
        obs = {w.world_id: generate_observations(w, include_distractors=True) for w in wl}
        sysres = run_b3_b4(wl, bundles, obs, run_id=f"rescue_seed{seed}")
        rows.append({"seed": seed, "systems": sysres, "runtime_sec": round(time.time() - t0, 2)})
        print("SEED", seed, {k: (v["mean_query_accuracy"], v["bcr"]) for k, v in sysres.items()})
    mini = {
        "protocol": "symbolic B3/B4 k8; worlds_per_tier=6; seeds 100-105; new labelled study",
        "note": "B3 Acc/BCR identical across seeds under this protocol is NOT independent replication.",
        "runs": rows,
    }
    (OUT_P1 / "alt_seed_symbolic_mini.json").write_text(json.dumps(mini, indent=2))
    # also store compact seed summary for p2 aggregate
    return rows


def cmd_density(_args):
    OUT_P2.mkdir(parents=True, exist_ok=True)
    dens_rows = []
    t0 = time.time()
    for dens in (0.0, 0.2, 0.5, 0.8, 1.0):
        wl = protocol_worlds(200, wpt=8, density_override=dens, tiers=("medium",))
        bundles = []
        for w in wl:
            bundles.extend(generate_scaled_bundles(w))
        obs = {w.world_id: generate_observations(w, include_distractors=True) for w in wl}
        sysres = run_b3_b4(wl, bundles, obs, run_id="rescue_density")
        dens_rows.append(
            {
                "relation_density": dens,
                "mean_events": round(sum(len(w.events) for w in wl) / len(wl), 1),
                "systems": sysres,
            }
        )
        print("DENS", dens, dens_rows[-1]["mean_events"])
    payload = {
        "protocol": "symbolic B3/B4; seed_base=200; 8 medium worlds; density override; distractors ON",
        "runtime_sec": round(time.time() - t0, 2),
        "runs": dens_rows,
    }
    (OUT_P2 / "relation_density_medium.json").write_text(json.dumps(payload, indent=2))
    return payload


def cmd_distractors(_args):
    OUT_P2.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    wl = protocol_worlds(100, wpt=6)
    bundles = []
    for w in wl:
        bundles.extend(generate_scaled_bundles(w))
    dist_rows = []
    for flag in (True, False):
        obs = {w.world_id: generate_observations(w, include_distractors=flag) for w in wl}
        dist_rows.append({"include_distractors": flag, "systems": run_b3_b4(wl, bundles, obs, "rescue_dist")})
        print("DIST", flag)
    payload = {
        "protocol": "symbolic B3/B4; seed 100; wpt=6; toggle include_distractors",
        "runtime_sec": round(time.time() - t0, 2),
        "runs": dist_rows,
    }
    (OUT_P2 / "distractor_ablation.json").write_text(json.dumps(payload, indent=2))
    return payload


def cmd_shortcuts(_args):
    OUT_P2.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    wl = protocol_worlds(100, wpt=6)
    worlds = {w.world_id: w for w in wl}
    bundles = []
    for w in wl:
        bundles.extend(generate_scaled_bundles(w))

    empty_preds = [
        Prediction(bundle_id=b.bundle_id, query_id=q.query_id, predicted_answer=None, system_id="empty", run_id="p2")
        for b in bundles
        for q in b.queries
    ]
    _, agg, _ = evaluate_predictions(worlds, bundles, empty_preds)
    empty = agg_dict(agg)

    fam_vals = defaultdict(list)
    for b in bundles:
        for q in b.queries:
            fam_vals[q.family.value].append(json.dumps(q.gold_answer, sort_keys=True, default=str))
    family_mode = {fam: json.loads(Counter(vals).most_common(1)[0][0]) for fam, vals in fam_vals.items()}
    maj = [
        Prediction(
            bundle_id=b.bundle_id,
            query_id=q.query_id,
            predicted_answer=family_mode[q.family.value],
            system_id="family_majority",
            run_id="p2",
        )
        for b in bundles
        for q in b.queries
    ]
    _, agg, _ = evaluate_predictions(worlds, bundles, maj)
    majority = agg_dict(agg)

    gold = [
        Prediction(
            bundle_id=b.bundle_id,
            query_id=q.query_id,
            predicted_answer=q.gold_answer,
            system_id="gold",
            run_id="p2",
        )
        for b in bundles
        for q in b.queries
    ]
    _, agg, _ = evaluate_predictions(worlds, bundles, gold)
    goldm = agg_dict(agg)

    rng = random.Random(0)
    by_fam = defaultdict(list)
    for b in bundles:
        for q in b.queries:
            by_fam[q.family.value].append(q.gold_answer)
    shuffled_pool = {fam: rng.sample(vals, len(vals)) for fam, vals in by_fam.items()}
    idx = {fam: 0 for fam in shuffled_pool}
    shuf = []
    for b in bundles:
        for q in b.queries:
            ans = shuffled_pool[q.family.value][idx[q.family.value]]
            idx[q.family.value] += 1
            shuf.append(
                Prediction(
                    bundle_id=b.bundle_id,
                    query_id=q.query_id,
                    predicted_answer=ans,
                    system_id="family_shuffle",
                    run_id="p2",
                )
            )
    _, agg, _ = evaluate_predictions(worlds, bundles, shuf)
    shuffle = agg_dict(agg)

    payload = {
        "protocol": "seed100 wpt=6; empty / family-majority / family-shuffle / gold",
        "runtime_sec": round(time.time() - t0, 2),
        "empty": empty,
        "family_majority": majority,
        "family_shuffle": shuffle,
        "gold": goldm,
    }
    (OUT_P2 / "shortcut_baselines.json").write_text(json.dumps(payload, indent=2))
    print("SHORTCUTS", {k: payload[k] for k in ("empty", "family_majority", "family_shuffle", "gold")})
    return payload


def cmd_ablations_reprint(_args):
    OUT_P2.mkdir(parents=True, exist_ok=True)
    abl = []
    with (ROOT / "results" / "scaled" / "ablation_results.csv").open() as f:
        for r in csv.DictReader(f):
            if r["system"].startswith("H-") or r["system"] in ("H0_ltkm_cap150_ret8", "H0_ltkm_unconstrained"):
                abl.append(
                    {
                        "system": r["system"],
                        "Acc": round(float(r["mean_query_accuracy"]), 4),
                        "BCR": round(float(r["bcr"]), 4),
                        "Gap_query": round(float(r["gap_query"]), 4),
                    }
                )
    payload = {"source": "results/scaled/ablation_results.csv", "label": "FROZEN reprint", "rows": abl}
    (OUT_P2 / "frozen_h0_ablations_reprinted.json").write_text(json.dumps(payload, indent=2))
    print("ablations", len(abl))
    return payload


def cmd_budget(_args):
    OUT_P3.mkdir(parents=True, exist_ok=True)
    wl = protocol_worlds(100, wpt=6)
    bundles = []
    for w in wl:
        bundles.extend(generate_scaled_bundles(w))
    obs = {w.world_id: generate_observations(w, True) for w in wl}
    rows = []
    t0 = time.time()
    for name, factory in [
        ("B2_latest_only", lambda: LatestStateMemory(run_id="p3")),
        ("B3_recency_k3", lambda: RecencyWeightedMemory(k=3, recency_coef=0.15, run_id="p3")),
        ("B3_recency_k5", lambda: RecencyWeightedMemory(k=5, recency_coef=0.15, run_id="p3")),
        ("B3_recency_k8", lambda: RecencyWeightedMemory(k=8, recency_coef=0.15, run_id="p3")),
        ("B4_bm25_k3", lambda: BM25RetrievalMemory(k=3, run_id="p3")),
        ("B4_bm25_k8", lambda: BM25RetrievalMemory(k=8, run_id="p3")),
    ]:
        bms, agg, _ = run_adapter(factory(), wl, bundles, obs)
        d = agg.to_dict()
        row = {
            "Acc": round(d["mean_query_accuracy"], 4),
            "BCR": round(d["bcr"], 4),
            "Gapq": round(d["mean_query_accuracy"] - d["bcr"], 4),
            "n_worlds": len(wl),
            "n_bundles": len(bundles),
            "n_queries": sum(len(b.queries) for b in bundles),
            "system": name,
        }
        rows.append(row)
        print(name, row)
    payload = {
        "label": "NEW — not Option A",
        "protocol": "seed100; wpt=6; retrieval-budget / latest-only sensitivity",
        "purpose": "Show Acc can match while BCR differs (B2 vs B3_k3); B3 varies with k, not only seeds",
        "runtime_sec": round(time.time() - t0, 2),
        "rows": rows,
    }
    (OUT_P3 / "retrieval_budget_sensitivity.json").write_text(json.dumps(payload, indent=2))
    return payload


def cmd_p2_aggregate(_args):
    """Rebuild rescue_p2_robustness.json from component NEW runs + frozen ablation reprint."""
    OUT_P2.mkdir(parents=True, exist_ok=True)
    seed_rows = cmd_seeds(_args)
    density = cmd_density(_args)
    distractor = cmd_distractors(_args)
    shortcuts = cmd_shortcuts(_args)
    abl = cmd_ablations_reprint(_args)
    seed_summary = {
        "protocol": "symbolic B3/B4 k8; wpt=6; seeds 100-105; distractors ON",
        "note": "B3 Acc/BCR identical across seeds under this protocol (template-heavy generator). Do not treat as independent replication.",
        "runs": [
            {
                "seed": r["seed"],
                "B3": {
                    "Acc": r["systems"]["B3_recency_k8"]["mean_query_accuracy"],
                    "BCR": r["systems"]["B3_recency_k8"]["bcr"],
                    "Gap": r["systems"]["B3_recency_k8"]["gap_query"],
                },
                "B4": {
                    "Acc": r["systems"]["B4_bm25_k8"]["mean_query_accuracy"],
                    "BCR": r["systems"]["B4_bm25_k8"]["bcr"],
                    "Gap": r["systems"]["B4_bm25_k8"]["gap_query"],
                },
            }
            for r in seed_rows
        ],
    }
    payload = {
        "label": "NEW — not Option A freeze",
        "environment_blockers": [
            "Stronger LLM reader NOT RUN in packaging environment unless mlx-lm + weights available"
        ],
        "experiments": {
            "seed_sweep_wpt6": seed_summary,
            "relation_density_medium": density,
            "distractor_ablation": distractor,
            "shortcut_baselines": shortcuts,
            "frozen_h0_ablations_reprinted": abl,
        },
    }
    (OUT_P2 / "rescue_p2_robustness.json").write_text(json.dumps(payload, indent=2))
    print("wrote", OUT_P2 / "rescue_p2_robustness.json")


def cmd_all(args):
    cmd_gold(args)
    cmd_budget(args)
    cmd_p2_aggregate(args)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name, fn in [
        ("gold", cmd_gold),
        ("seeds", cmd_seeds),
        ("density", cmd_density),
        ("distractors", cmd_distractors),
        ("shortcuts", cmd_shortcuts),
        ("ablations-reprint", cmd_ablations_reprint),
        ("budget", cmd_budget),
        ("p2-aggregate", cmd_p2_aggregate),
        ("all", cmd_all),
    ]:
        sp = sub.add_parser(name)
        sp.set_defaults(func=fn)
    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
