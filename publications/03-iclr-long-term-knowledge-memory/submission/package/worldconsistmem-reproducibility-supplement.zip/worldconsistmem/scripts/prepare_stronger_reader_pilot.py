#!/usr/bin/env python3
"""Prepare a NEW limited stronger-reader transfer pilot (no paid API calls).

Predeclares stratified sampling over the frozen H4 universe, estimates cost for
gpt-4o-mini under the frozen H4 prompt/scoring protocol, and writes artefacts
under results/new/stronger_reader_pilot/.

Does NOT mutate Option A. Does NOT make network/API calls.
"""

from __future__ import annotations

import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "new" / "stronger_reader_pilot"

# --- Predeclared pilot constants (frozen before any API use) ---
LABEL = "NEW_limited_stronger_reader_transfer_pilot"
NOT_OPTION_A = True
SAMPLE_SEED = 20260909
TARGET_QUERIES = 144  # within required 100–200
MEMORY_SYSTEM = "H0_ltkm_cap150_ret8"
PROMPT_TAG = "prompt_v3_k3_mt48"
# Exact API model id (pinned snapshot). Substantially stronger than Qwen2.5-3B; lowest-cost suitable.
MODEL_ID = "gpt-4o-mini-2024-07-18"
MODEL_ALIAS = "gpt-4o-mini"
# OpenAI list prices (USD / 1M tokens); conservative max uses full list rates (no cache/batch discount).
PRICE_IN_PER_M = 0.15
PRICE_OUT_PER_M = 0.60
MAX_BUDGET_USD = 5.0
MAX_TOKENS = 48
TEMPERATURE = 0.0
CHAT_OVERHEAD_TOKENS = 40  # system/user framing overhead beyond measured prompt_tokens
INPUT_SAFETY = 1.25  # inflate p95 prompt tokens for max-cost bound


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def h4_world_ids() -> set[str]:
    wi = json.loads((ROOT / "data" / "scaled" / "world_index.json").read_text())
    by_tier: dict[str, list] = defaultdict(list)
    for r in wi:
        by_tier[r["tier"]].append(r)
    ids: set[str] = set()
    for t in ("small", "medium", "large"):
        for r in by_tier[t][:6]:
            ids.add(r["world_id"])
    return ids


def load_h4_bundles() -> list[dict[str, Any]]:
    ids = h4_world_ids()
    out = []
    with (ROOT / "data" / "scaled" / "bundles.jsonl").open() as f:
        for line in f:
            b = json.loads(line)
            if b["world_id"] not in ids:
                continue
            md = b.get("metadata") or {}
            b["_tier"] = md.get("tier")
            b["_difficulty"] = md.get("difficulty")
            out.append(b)
    return out


def load_prompt_token_index() -> dict[str, int]:
    """Map query_id -> prompt_tokens from frozen Qwen H0 cache (same evidence protocol)."""
    path = ROOT / "results" / "scaled" / "run2" / "llm_reader_cache" / "Qwen2.5-3B-Instruct-4bit.jsonl"
    latest: dict[str, int] = {}
    with path.open() as f:
        for line in f:
            r = json.loads(line)
            if r.get("memory_system") != MEMORY_SYSTEM:
                continue
            pt = r.get("prompt_tokens")
            if pt:
                latest[r["query_id"]] = int(pt)
    return latest


def stratified_bundle_sample(
    bundles: list[dict[str, Any]], target_q: int, seed: int
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Sample complete bundles stratified by (tier × difficulty), proportional to query mass.

    Complete bundles preserve BCR scoring under the frozen protocol.
    Query-family coverage is a reported post-sample diagnostic (families are nested in bundles).
    """
    rng = random.Random(seed)
    nq_by: dict[tuple[str, str], int] = defaultdict(int)
    by_s: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for b in bundles:
        key = (str(b["_tier"]), str(b["_difficulty"]))
        nq = len(b["queries"])
        nq_by[key] += nq
        by_s[key].append(b)

    total_q = sum(nq_by.values())
    items = sorted(nq_by.items())
    raw = [(k, target_q * v / total_q) for k, v in items]
    floors = [(k, int(x)) for k, x in raw]
    used = sum(f for _, f in floors)
    fracs = sorted([(raw[i][1] - floors[i][1], raw[i][0]) for i in range(len(raw))], reverse=True)
    alloc_q = {k: f for k, f in floors}
    for _, k in fracs:
        if used >= target_q:
            break
        alloc_q[k] += 1
        used += 1

    selected: list[dict[str, Any]] = []
    for stratum, qquota in sorted(alloc_q.items()):
        pool = by_s[stratum][:]
        rng.shuffle(pool)
        got = 0
        for b in pool:
            nq = len(b["queries"])
            if got >= qquota:
                break
            if got > 0 and got + nq > qquota + 8:
                continue
            selected.append(b)
            got += nq

    fam = Counter()
    strata = Counter()
    examples = []
    for b in selected:
        strata[(b["_tier"], b["_difficulty"])] += 1
        for q in b["queries"]:
            fam[q["family"]] += 1
            examples.append(
                {
                    "bundle_id": b["bundle_id"],
                    "world_id": b["world_id"],
                    "query_id": q["query_id"],
                    "family": q["family"],
                    "tier": b["_tier"],
                    "difficulty": b["_difficulty"],
                    "memory_system": MEMORY_SYSTEM,
                }
            )

    meta = {
        "procedure": (
            "Deterministic proportional allocation of target query mass across "
            "(world_tier × bundle_difficulty) strata on the frozen H4 universe "
            "(first 6 worlds/tier, seed-100 scaled freeze). Within each stratum, "
            "shuffle bundles with SAMPLE_SEED and greedily take complete bundles "
            "until the stratum query quota is met (allow +8 query overrun to avoid "
            "splitting bundles). All queries in selected bundles are evaluated so "
            "BCR remains well-defined."
        ),
        "sample_seed": seed,
        "target_queries": target_q,
        "stratum_query_quotas": {f"{a}|{b}": v for (a, b), v in alloc_q.items()},
        "selected_bundles": len(selected),
        "selected_queries": len(examples),
        "bundle_counts_by_stratum": {f"{a}|{b}": v for (a, b), v in strata.items()},
        "query_family_counts": dict(fam),
        "universe": "H4_first_6_worlds_per_tier_seed100",
        "n_universe_bundles": len(bundles),
        "n_universe_queries": total_q,
    }
    return examples, meta


def estimate_cost(examples: list[dict[str, Any]], pt_index: dict[str, int]) -> dict[str, Any]:
    pts = [pt_index.get(e["query_id"]) for e in examples]
    known = [p for p in pts if p is not None]
    missing = len(pts) - len(known)
    if known:
        known_sorted = sorted(known)
        mean_pt = sum(known) / len(known)
        p95_pt = known_sorted[int(0.95 * (len(known_sorted) - 1))]
    else:
        mean_pt, p95_pt = 350.0, 450.0

    n = len(examples)
    # Expected: mean prompt + overhead; mean output ~25 tokens (JSON short)
    exp_in = n * (mean_pt + CHAT_OVERHEAD_TOKENS)
    exp_out = n * 25
    exp_cost = exp_in * PRICE_IN_PER_M / 1e6 + exp_out * PRICE_OUT_PER_M / 1e6
    # Maximum bound: p95 * safety + overhead; output = max_tokens
    max_in = n * (p95_pt * INPUT_SAFETY + CHAT_OVERHEAD_TOKENS)
    max_out = n * MAX_TOKENS
    max_cost = max_in * PRICE_IN_PER_M / 1e6 + max_out * PRICE_OUT_PER_M / 1e6

    return {
        "model_id": MODEL_ID,
        "model_alias": MODEL_ALIAS,
        "n_examples": n,
        "n_prompt_token_refs": len(known),
        "n_missing_prompt_token_refs": missing,
        "mean_prompt_tokens_ref": mean_pt,
        "p95_prompt_tokens_ref": p95_pt,
        "est_input_tokens_expected": int(exp_in),
        "est_output_tokens_expected": int(exp_out),
        "est_input_tokens_maximum": int(max_in),
        "est_output_tokens_maximum": int(max_out),
        "price_usd_per_m_input": PRICE_IN_PER_M,
        "price_usd_per_m_output": PRICE_OUT_PER_M,
        "estimated_expected_cost_usd": round(exp_cost, 6),
        "estimated_maximum_cost_usd": round(max_cost, 6),
        "budget_cap_usd": MAX_BUDGET_USD,
        "fits_under_budget": max_cost < MAX_BUDGET_USD,
        "pricing_note": (
            "Maximum uses list rates with p95×1.25 input inflation and max_tokens "
            "output; no prompt-cache or batch discounts assumed."
        ),
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    bundles = load_h4_bundles()
    examples, sample_meta = stratified_bundle_sample(bundles, TARGET_QUERIES, SAMPLE_SEED)
    pt_index = load_prompt_token_index()
    cost = estimate_cost(examples, pt_index)

    protocol = {
        "label": LABEL,
        "not_option_a": NOT_OPTION_A,
        "description": (
            "Limited stronger-reader transfer pilot: re-read frozen H4 evidence packs "
            "for a stratified subset under the identical prompt_v3_k3_mt48 protocol. "
            "Not a full model-scale evaluation; not pooled with Option A tables."
        ),
        "memory_system": MEMORY_SYSTEM,
        "prompt_tag": PROMPT_TAG,
        "temperature": TEMPERATURE,
        "max_tokens": MAX_TOKENS,
        "max_evidence_items": 3,
        "evidence_json_cap": 1200,
        "scoring": "frozen evaluate_bundle / Acc + BCR (Φ); same parsers as H4 JSON reader",
        "model_id": MODEL_ID,
        "sample": sample_meta,
        "cost": cost,
        "output_paths": {
            "root": str(OUT.relative_to(ROOT)),
            "sample_manifest": "sample_manifest.jsonl",
            "cost_estimate": "COST_ESTIMATE.json",
            "pilot_config": "PILOT_CONFIG.json",
            "cache": "api_cache.jsonl",
            "predictions": "predictions.jsonl",
            "metrics": "metrics.json",
            "run_log": "run.log",
            "spend_ledger": "spend_ledger.jsonl",
            "blocker": "EXECUTION_BLOCKER.json",
        },
        "execution_gates": [
            "estimated_maximum_cost_usd < 5.0",
            "OPENAI_API_KEY must be set in the environment",
            "runner stops if cumulative estimated/reported spend >= 5.0",
            "no Option A path writes",
        ],
    }

    # Write sample manifest
    man_path = OUT / "sample_manifest.jsonl"
    with man_path.open("w") as f:
        for ex in examples:
            f.write(json.dumps(ex, sort_keys=True) + "\n")

    (OUT / "COST_ESTIMATE.json").write_text(json.dumps(cost, indent=2, sort_keys=True) + "\n")
    (OUT / "PILOT_CONFIG.json").write_text(json.dumps(protocol, indent=2, sort_keys=True) + "\n")

    # Execution blocker: no API key in this environment (prepare-only).
    import os

    key_present = bool(os.environ.get("OPENAI_API_KEY"))
    blocker = {
        "paid_calls_executed": False,
        "reason": (
            None
            if (cost["fits_under_budget"] and key_present)
            else (
                "OPENAI_API_KEY unset — pilot prepared but paid calls blocked"
                if cost["fits_under_budget"]
                else "estimated_maximum_cost_usd exceeds USD 5 — do not run"
            )
        ),
        "fits_under_budget": cost["fits_under_budget"],
        "openai_api_key_present": key_present,
        "next_step": (
            "Set OPENAI_API_KEY and run: PYTHONPATH=src python scripts/run_stronger_reader_pilot.py "
            "--execute"
            if cost["fits_under_budget"]
            else "Reduce n or choose a cheaper model; do not execute."
        ),
    }
    (OUT / "EXECUTION_BLOCKER.json").write_text(json.dumps(blocker, indent=2, sort_keys=True) + "\n")

    readme = f"""# NEW — Limited stronger-reader transfer pilot

**Label:** `{LABEL}`  
**Not Option A.** Do not pool with frozen Option A tables.

## Predeclared design

| Item | Value |
|------|-------|
| Model | `{MODEL_ID}` (`{MODEL_ALIAS}`) |
| Examples | {cost['n_examples']} queries in {sample_meta['selected_bundles']} complete bundles |
| Seed | `{SAMPLE_SEED}` |
| Stratification | world tier × bundle difficulty (proportional); complete bundles |
| Memory system | `{MEMORY_SYSTEM}` |
| Protocol | frozen `{PROMPT_TAG}` (temp=0, max_tokens=48, ≤3 evidence) |
| Est. max cost | **USD {cost['estimated_maximum_cost_usd']}** (cap {MAX_BUDGET_USD}) |
| Est. expected cost | USD {cost['estimated_expected_cost_usd']} |

## Status

Paid calls: **not executed** in prepare step. See `EXECUTION_BLOCKER.json`.

## Runner

```bash
PYTHONPATH=src python scripts/run_stronger_reader_pilot.py --execute
```

Requires `OPENAI_API_KEY`. Resumable via `api_cache.jsonl`. Stops at USD {MAX_BUDGET_USD}.
"""
    (OUT / "README.md").write_text(readme)

    manifest_lines = []
    for name in [
        "sample_manifest.jsonl",
        "COST_ESTIMATE.json",
        "PILOT_CONFIG.json",
        "EXECUTION_BLOCKER.json",
        "README.md",
    ]:
        p = OUT / name
        manifest_lines.append(f"{sha_bytes(p.read_bytes())}  {name}")
    (OUT / "MANIFEST.sha256").write_text("\n".join(manifest_lines) + "\n")

    print(json.dumps({"wrote": str(OUT), "cost": cost, "blocker": blocker, "sample": {
        "n_queries": sample_meta["selected_queries"],
        "n_bundles": sample_meta["selected_bundles"],
        "families": sample_meta["query_family_counts"],
    }}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
