#!/usr/bin/env python3
"""Verify frozen Option A checksums and print manuscript headline numbers."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Authoritative hashes from results/scaled/FINAL_EXPERIMENT_STATUS.md
EXPECTED = {
    "data/scaled/manifest.json": "37aa8604c3e6d87691332f66d2f7c0ab93578f2fe468bc29f7e8217c1675af3f",
    "results/scaled/system_results.csv": "eb5bd5fa87496586bd830e5f685b9950e119f9fd0ac491194b3f003343f9a2a8",
}

# Smoke dataset hash is over a concatenated canonicalisation used in tests.
SMOKE_EXPECTED = "3aa67ed1b6a39be3d9e1805d14f7d5ce7cc05f4655bdce0bc4ff49900c14c7ab"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ok = True
    print("=== Frozen file hashes ===")
    for rel, exp in EXPECTED.items():
        p = ROOT / rel
        got = sha256(p)
        status = "OK" if got == exp else "MISMATCH"
        if status != "OK":
            ok = False
        print(f"{status}  {rel}")
        print(f"       expected {exp}")
        print(f"       got      {got}")

    # Smoke hash via package helper if available
    sys.path.insert(0, str(ROOT / "src"))
    try:
        from worldconsistmem.baselines.load import EXPECTED_SMOKE_SHA256, smoke_checksum

        got = smoke_checksum(ROOT / "data" / "smoke")
        status = "OK" if got == EXPECTED_SMOKE_SHA256 == SMOKE_EXPECTED else "MISMATCH"
        if status != "OK":
            ok = False
        print(f"{status}  data/smoke (canonical)")
        print(f"       expected {SMOKE_EXPECTED}")
        print(f"       got      {got}")
    except Exception as e:
        print("WARN  could not verify smoke canonical hash via helper:", e)

    # H4 frozen protocol: embedded frozen_config_hash MUST equal SHA-256 of protocol file.
    cfg = json.loads((ROOT / "results/scaled/h4_frozen_config.json").read_text())
    proto = ROOT / "results/scaled/h4_frozen_protocol.json"
    print("=== H4 frozen config ===")
    print("frozen_config_hash (embedded):", cfg.get("frozen_config_hash"))
    if proto.exists():
        print("h4_frozen_protocol.json sha256:", sha256(proto))
        if cfg.get("frozen_config_hash") != sha256(proto):
            print("MISMATCH protocol file vs embedded frozen_config_hash")
            ok = False
        else:
            print("OK  frozen_config_hash == SHA-256(h4_frozen_protocol.json)")
    else:
        print("MISSING h4_frozen_protocol.json")
        ok = False
    print("manifest_sha256:             ", cfg.get("manifest_sha256"))
    print("wrapper file_sha256:         ", sha256(ROOT / "results/scaled/h4_frozen_config.json"))
    try:
        from worldconsistmem.h4_runtime import frozen_config_hash as runtime_hash

        rh = runtime_hash()
        print("runtime frozen_config_hash():", rh)
        if rh != cfg.get("frozen_config_hash"):
            print("MISMATCH runtime vs embedded")
            ok = False
    except Exception as e:
        print("WARN  runtime hash check failed:", e)

    print("=== Manuscript headline rows (raw CSV) ===")
    rows = {r["system"]: r for r in csv.DictReader((ROOT / "results/scaled/system_results.csv").open())}
    for sys_id in [
        "B2_latest_only",
        "B3_recency_k3",
        "B3_recency_k8",
        "B4_bm25_k8",
        "B1_flat_cap150_compact",
        "H0_ltkm_cap150_ret8",
    ]:
        r = rows[sys_id]
        print(
            f"{sys_id}: Acc={r['mean_query_accuracy']} BCR={r['bcr']} Gapq={r['gap_query']}"
        )

    qwen = ROOT / "results/scaled/run2/qwen_system_results.csv"
    if qwen.exists():
        print("=== Qwen H4 Option A (run2) ===")
        for r in csv.DictReader(qwen.open()):
            name = r.get("memory_system") or r.get("system") or r.get("system_id") or "?"
            print(f"{name}: Acc={r.get('mean_query_accuracy')} BCR={r.get('bcr')}")

    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
