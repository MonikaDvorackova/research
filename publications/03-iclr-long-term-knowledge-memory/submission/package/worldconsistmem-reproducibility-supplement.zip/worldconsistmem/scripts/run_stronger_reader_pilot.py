#!/usr/bin/env python3
"""Execute the NEW limited stronger-reader transfer pilot (budget-capped).

Default: dry-run report only (no paid calls).
Paid path: --execute with OPENAI_API_KEY, only if COST_ESTIMATE max < USD 5.

Preserves frozen prompt_v3_k3_mt48 (format_prompt) + H0 evidence retrieval + JSON parse.
Caches responses; resumable; stops at cumulative spend USD 5.
Does not write Option A paths.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.error
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from worldconsistmem.baselines.interface import ABSTAIN_TOKEN  # noqa: E402
from worldconsistmem.generate import GeneratedWorld  # noqa: E402
from worldconsistmem.llm_reader import (  # noqa: E402
    MAX_EVIDENCE_ITEMS,
    MAX_TOKENS,
    TEMPERATURE,
    _parse_json_answer,
    build_evidence_from_ltkm_pack,
    format_prompt,
)
from worldconsistmem.ltkm.adapter import LTKMAdapter  # noqa: E402
from worldconsistmem.ltkm.memory import LTKMConfig  # noqa: E402
from worldconsistmem.ltkm.retrieval import LTKMRetriever  # noqa: E402
from worldconsistmem.metrics import aggregate_metrics, evaluate_bundle  # noqa: E402
from worldconsistmem.models import (  # noqa: E402
    AnswerSchema,
    ConstraintFamily,
    Prediction,
    Query,
    QueryBundle,
    QueryFamily,
)
from worldconsistmem.observe import generate_observations  # noqa: E402
from worldconsistmem.scaled_generate import generate_scaled_world  # noqa: E402

OUT = ROOT / "results" / "new" / "stronger_reader_pilot"
BUDGET_USD = 5.0
MEMORY_SYSTEM = "H0_ltkm_cap150_ret8"
PROMPT_TAG = "prompt_v3_k3_mt48"


def load_json(p: Path) -> Any:
    return json.loads(p.read_text())


def append_jsonl(path: Path, row: dict[str, Any]) -> None:
    with path.open("a") as f:
        f.write(json.dumps(row, sort_keys=True, default=str) + "\n")


def load_cache(path: Path) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    if not path.exists():
        return out
    with path.open() as f:
        for line in f:
            if line.strip():
                r = json.loads(line)
                out[r["cache_key"]] = r
    return out


def estimate_call_cost(pt: int, ct: int, price_in: float, price_out: float) -> float:
    return pt * price_in / 1e6 + ct * price_out / 1e6


def openai_chat(model: str, prompt: str, api_key: str) -> dict[str, Any]:
    body = {
        "model": model,
        "temperature": TEMPERATURE,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {
                "role": "system",
                "content": "You are a careful evidence-grounded answering function. Output JSON only.",
            },
            {"role": "user", "content": prompt},
        ],
    }
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=120) as resp:
        return json.loads(resp.read().decode("utf-8"))


def make_h0_adapter():
    return LTKMAdapter(
        LTKMConfig(
            system_id=MEMORY_SYSTEM,
            run_id=MEMORY_SYSTEM,
            max_logical_records=150,
            max_retrieval_records=8,
        )
    )


def rebuild_query(q: dict[str, Any]) -> Query:
    return Query(
        query_id=q["query_id"],
        bundle_id=q["bundle_id"],
        family=QueryFamily(q["family"]),
        text=q["text"],
        structured=q["structured"],
        target_time=q.get("target_time"),
        target_interval=None,
        gold_answer=q["gold_answer"],
        answer_schema=AnswerSchema(q["answer_schema"]),
        applicable_constraints=[ConstraintFamily(c) for c in q["applicable_constraints"]],
        supporting_event_ids=q["supporting_event_ids"],
        supporting_provenance_ids=q["supporting_provenance_ids"],
        metadata=q.get("metadata") or {},
    )


def rebuild_bundle(row: dict[str, Any]) -> QueryBundle:
    return QueryBundle(
        bundle_id=row["bundle_id"],
        world_id=row["world_id"],
        focal_entities=row["focal_entities"],
        queries=[rebuild_query(q) for q in row["queries"]],
        description=row.get("description", ""),
        metadata=row.get("metadata") or {},
    )


def load_observations_by_world(worlds: dict[str, GeneratedWorld]) -> dict[str, list]:
    """Match H4: regenerate observations from gold worlds (no Option A writes)."""
    return {wid: generate_observations(w) for wid, w in worlds.items()}


def cache_key(model_id: str, query_id: str) -> str:
    return hashlib.sha256(f"{model_id}|{MEMORY_SYSTEM}|{query_id}|{PROMPT_TAG}".encode()).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--execute", action="store_true", help="Make paid API calls")
    args = ap.parse_args()

    cfg_path = OUT / "PILOT_CONFIG.json"
    cost_path = OUT / "COST_ESTIMATE.json"
    man_path = OUT / "sample_manifest.jsonl"
    if not cfg_path.exists() or not cost_path.exists():
        print("Run prepare_stronger_reader_pilot.py first.", file=sys.stderr)
        return 2

    cfg = load_json(cfg_path)
    cost = load_json(cost_path)
    report = {
        "label": cfg["label"],
        "not_option_a": True,
        "model_id": cfg["model_id"],
        "n_examples": cost["n_examples"],
        "est_input_tokens_expected": cost["est_input_tokens_expected"],
        "est_output_tokens_expected": cost["est_output_tokens_expected"],
        "est_input_tokens_maximum": cost["est_input_tokens_maximum"],
        "est_output_tokens_maximum": cost["est_output_tokens_maximum"],
        "estimated_expected_cost_usd": cost["estimated_expected_cost_usd"],
        "estimated_maximum_cost_usd": cost["estimated_maximum_cost_usd"],
        "sample_seed": cfg["sample"]["sample_seed"],
        "stratification": cfg["sample"]["procedure"],
        "output_paths": {k: str(OUT / v) if not str(v).startswith("results") else str(ROOT / v) for k, v in cfg["output_paths"].items() if k != "root"},
        "output_root": str(OUT),
        "execute_requested": args.execute,
    }
    print(json.dumps(report, indent=2))

    if not cost["fits_under_budget"]:
        print("BLOCKED: estimated maximum exceeds USD 5.", file=sys.stderr)
        return 3
    if not args.execute:
        print("Dry-run only (no paid calls). Pass --execute after setting OPENAI_API_KEY.")
        return 0

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        blocker = {
            "paid_calls_executed": False,
            "reason": "OPENAI_API_KEY unset",
            "fits_under_budget": True,
        }
        (OUT / "EXECUTION_BLOCKER.json").write_text(json.dumps(blocker, indent=2) + "\n")
        print("BLOCKED: OPENAI_API_KEY unset.", file=sys.stderr)
        return 4

    model_id = cfg["model_id"]
    examples = [json.loads(l) for l in man_path.open() if l.strip()]
    from prepare_stronger_reader_pilot import load_h4_bundles

    bundles_raw = {b["bundle_id"]: b for b in load_h4_bundles()}
    world_ids = {ex["world_id"] for ex in examples}
    wi = {r["world_id"]: r for r in json.loads((ROOT / "data" / "scaled" / "world_index.json").read_text())}
    worlds: dict[str, GeneratedWorld] = {}
    for wid in world_ids:
        row = wi[wid]
        worlds[wid] = generate_scaled_world(int(row["seed"]), int(wid.split("_")[-1]), tier=row["tier"])
    obs_by_world = load_observations_by_world(worlds)

    cache_path = OUT / "api_cache.jsonl"
    pred_path = OUT / "predictions.jsonl"
    spend_path = OUT / "spend_ledger.jsonl"
    cache = load_cache(cache_path)
    cumulative = 0.0
    if spend_path.exists():
        with spend_path.open() as f:
            for line in f:
                if line.strip():
                    cumulative += float(json.loads(line).get("cost_usd", 0.0))

    price_in = float(cost["price_usd_per_m_input"])
    price_out = float(cost["price_usd_per_m_output"])
    n_new = n_cache = 0

    # Group examples by world for one ingest pass
    by_world: dict[str, list[dict]] = defaultdict(list)
    for ex in examples:
        by_world[ex["world_id"]].append(ex)

    pred_answers: dict[str, Any] = {}
    # seed from cache
    for ck, row in cache.items():
        if row.get("predicted_answer") is not None or row.get("status") == "abstain":
            pred_answers[row["query_id"]] = (
                ABSTAIN_TOKEN if row.get("status") == "abstain" else row.get("predicted_answer")
            )

    with (OUT / "run.log").open("a") as log:
        log.write(f"\n--- execute {time.time()} cum={cumulative}\n")
        for wid, exs in by_world.items():
            adapter = make_h0_adapter()
            adapter.reset()
            for o in obs_by_world.get(wid, []):
                adapter.ingest(o)
            for ex in exs:
                if cumulative >= BUDGET_USD:
                    log.write(f"STOP budget cum={cumulative}\n")
                    break
                qid = ex["query_id"]
                ck = cache_key(model_id, qid)
                if ck in cache and cache[ck].get("raw_output") is not None:
                    n_cache += 1
                    row = cache[ck]
                    pred_answers[qid] = (
                        ABSTAIN_TOKEN if row.get("status") == "abstain" else row.get("predicted_answer")
                    )
                    continue
                q = rebuild_query(next(qq for qq in bundles_raw[ex["bundle_id"]]["queries"] if qq["query_id"] == qid))
                pack = LTKMRetriever(adapter.memory).retrieve(q)
                rids = list(pack.record_ids)[:MAX_EVIDENCE_ITEMS]
                evid = build_evidence_from_ltkm_pack(q, pack.payloads, rids)
                prompt = format_prompt(evid)
                # pre-call guard
                rough_pt = max(50, len(prompt) // 3 + 40)
                if cumulative + estimate_call_cost(rough_pt, MAX_TOKENS, price_in, price_out) > BUDGET_USD:
                    log.write(f"STOP pre-call guard {qid}\n")
                    break
                try:
                    resp = openai_chat(model_id, prompt, api_key)
                except urllib.error.HTTPError as e:
                    log.write(f"HTTPError {qid}: {e}\n")
                    append_jsonl(cache_path, {"cache_key": ck, "query_id": qid, "status": "api_error", "detail": str(e), "raw_output": None})
                    continue
                text = resp["choices"][0]["message"]["content"]
                usage = resp.get("usage") or {}
                pt = int(usage.get("prompt_tokens") or 0)
                ct = int(usage.get("completion_tokens") or 0)
                call_cost = estimate_call_cost(pt, ct, price_in, price_out)
                cumulative += call_cost
                ans, abstain, prov, malformed, parsed = _parse_json_answer(text or "")
                status = "malformed" if malformed else ("abstain" if abstain else "ok")
                row = {
                    "cache_key": ck,
                    "query_id": qid,
                    "bundle_id": ex["bundle_id"],
                    "world_id": wid,
                    "memory_system": MEMORY_SYSTEM,
                    "model_id": model_id,
                    "label": "NEW_limited_stronger_reader_transfer_pilot",
                    "not_option_a": True,
                    "prompt_tag": PROMPT_TAG,
                    "retrieved_evidence_ids": rids,
                    "raw_output": text,
                    "parsed_output": parsed,
                    "predicted_answer": None if abstain else ans,
                    "predicted_provenance": prov,
                    "status": status,
                    "malformed": malformed,
                    "prompt_tokens": pt,
                    "completion_tokens": ct,
                    "cost_usd": call_cost,
                    "temperature": TEMPERATURE,
                    "max_tokens": MAX_TOKENS,
                }
                append_jsonl(cache_path, row)
                append_jsonl(spend_path, {"query_id": qid, "cost_usd": call_cost, "cumulative_usd": cumulative})
                append_jsonl(
                    pred_path,
                    {
                        "query_id": qid,
                        "bundle_id": ex["bundle_id"],
                        "predicted_answer": ABSTAIN_TOKEN if abstain else ans,
                        "status": status,
                        "model_id": model_id,
                        "label": "NEW_limited_stronger_reader_transfer_pilot",
                        "not_option_a": True,
                    },
                )
                pred_answers[qid] = ABSTAIN_TOKEN if abstain else ans
                cache[ck] = row
                n_new += 1
                log.write(f"ok {qid} ${call_cost:.6f} cum=${cumulative:.6f}\n")
            if cumulative >= BUDGET_USD:
                break

    # Score selected bundles that are complete in pred_answers
    bundle_metrics = []
    scored_bundles: list[QueryBundle] = []
    selected_bids = sorted({ex["bundle_id"] for ex in examples})
    for bid in selected_bids:
        brow = bundles_raw[bid]
        bobj = rebuild_bundle(brow)
        preds = []
        complete = True
        for q in bobj.queries:
            if q.query_id not in pred_answers:
                complete = False
                break
            preds.append(
                Prediction(
                    bundle_id=bid,
                    query_id=q.query_id,
                    predicted_answer=pred_answers[q.query_id],
                    predicted_provenance=None,
                    system_id=MEMORY_SYSTEM,
                    run_id="NEW_stronger_reader_pilot",
                    metadata={"reader": model_id, "label": "NEW_limited_stronger_reader_transfer_pilot"},
                )
            )
        if not complete:
            continue
        world = worlds[brow["world_id"]]
        bundle_metrics.append(evaluate_bundle(world, bobj, preds))
        scored_bundles.append(bobj)

    metrics: dict[str, Any] = {
        "label": "NEW_limited_stronger_reader_transfer_pilot",
        "not_option_a": True,
        "model_id": model_id,
        "n_new_calls": n_new,
        "n_cache_hits": n_cache,
        "cumulative_spend_usd": cumulative,
        "budget_usd": BUDGET_USD,
        "stopped_on_budget": cumulative >= BUDGET_USD,
        "n_bundles_scored": len(bundle_metrics),
    }
    if bundle_metrics:
        agg = aggregate_metrics(bundle_metrics, scored_bundles)
        metrics.update(
            {
                "mean_acc": agg.mean_query_accuracy,
                "bcr": agg.bcr,
                "gap_acc_bcr": agg.gap_mean_acc_minus_bcr,
            }
        )
    (OUT / "metrics.json").write_text(json.dumps(metrics, indent=2, sort_keys=True) + "\n")
    print(json.dumps(metrics, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
