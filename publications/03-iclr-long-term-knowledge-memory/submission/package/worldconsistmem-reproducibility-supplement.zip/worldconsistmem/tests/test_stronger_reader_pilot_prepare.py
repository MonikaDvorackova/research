#!/usr/bin/env python3
"""Determinism check for NEW stronger-reader pilot sampling (no API)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from prepare_stronger_reader_pilot import (  # noqa: E402
    SAMPLE_SEED,
    TARGET_QUERIES,
    load_h4_bundles,
    stratified_bundle_sample,
)


def test_sample_in_range_and_deterministic():
    bundles = load_h4_bundles()
    a, ma = stratified_bundle_sample(bundles, TARGET_QUERIES, SAMPLE_SEED)
    b, mb = stratified_bundle_sample(bundles, TARGET_QUERIES, SAMPLE_SEED)
    assert 100 <= len(a) <= 200
    assert [x["query_id"] for x in a] == [x["query_id"] for x in b]
    assert ma["selected_bundles"] == mb["selected_bundles"]
    # complete-bundle property: every selected query's siblings are present
    by_b = {}
    for x in a:
        by_b.setdefault(x["bundle_id"], set()).add(x["query_id"])
    full = {b["bundle_id"]: {q["query_id"] for q in b["queries"]} for b in bundles}
    for bid, qs in by_b.items():
        assert qs == full[bid]


def test_cost_estimate_artifact():
    p = ROOT / "results" / "new" / "stronger_reader_pilot" / "COST_ESTIMATE.json"
    assert p.exists()
    cost = json.loads(p.read_text())
    assert cost["fits_under_budget"] is True
    assert cost["estimated_maximum_cost_usd"] < 5.0
    assert cost["model_id"] == "gpt-4o-mini-2024-07-18"
