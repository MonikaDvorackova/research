"""Integrity tests for H4 frozen protocol hash and Option A checksums."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from worldconsistmem.baselines.load import EXPECTED_SMOKE_SHA256, smoke_checksum
from worldconsistmem.h4_runtime import frozen_config_hash, sha_file

ROOT = Path(__file__).resolve().parents[1]
SCALED = ROOT / "results" / "scaled"

EXPECTED_MANIFEST = "37aa8604c3e6d87691332f66d2f7c0ab93578f2fe468bc29f7e8217c1675af3f"
EXPECTED_SYSTEM_RESULTS = "eb5bd5fa87496586bd830e5f685b9950e119f9fd0ac491194b3f003343f9a2a8"
EXPECTED_PROTOCOL_HASH = "1d8a74f29b6b328853f7484a62e52d06ca4237e472e278258bad20acdb090db2"


def test_h4_frozen_config_hash_matches_protocol_file_and_runtime():
    """frozen_config_hash must equal SHA-256(h4_frozen_protocol.json) and runtime digest."""
    proto = SCALED / "h4_frozen_protocol.json"
    wrapper = SCALED / "h4_frozen_config.json"
    assert proto.is_file(), "missing h4_frozen_protocol.json"
    assert wrapper.is_file(), "missing h4_frozen_config.json"

    file_sha = sha_file(proto)
    runtime_sha = frozen_config_hash()
    embedded = json.loads(wrapper.read_text())["frozen_config_hash"]

    assert file_sha == runtime_sha == embedded == EXPECTED_PROTOCOL_HASH
    assert json.loads(wrapper.read_text())["manifest_sha256"] == EXPECTED_MANIFEST


def test_option_a_core_checksums_unchanged():
    assert smoke_checksum(ROOT / "data" / "smoke") == EXPECTED_SMOKE_SHA256
    assert sha_file(ROOT / "data" / "scaled" / "manifest.json") == EXPECTED_MANIFEST
    assert sha_file(SCALED / "system_results.csv") == EXPECTED_SYSTEM_RESULTS
