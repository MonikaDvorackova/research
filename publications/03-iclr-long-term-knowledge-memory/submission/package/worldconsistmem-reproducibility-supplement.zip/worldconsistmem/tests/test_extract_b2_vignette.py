"""Regression: ConstraintResult serialization for B2 vignette extraction."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from worldconsistmem.models import ConstraintFamily, ConstraintResult

ROOT = Path(__file__).resolve().parents[1]


def _import_extract():
    import importlib.util

    path = ROOT / "scripts" / "extract_b2_vignette.py"
    spec = importlib.util.spec_from_file_location("extract_b2_vignette", path)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_constraint_result_to_primitives_json_safe():
    mod = _import_extract()
    cr = ConstraintResult(
        passed=False,
        constraint_type=ConstraintFamily.TRANSITION,
        constraint_id="unit:trans",
        involved_query_ids=["q1", "q2"],
        involved_predicted_values={"historical": "__ABSTAIN__", "current": "p1"},
        explanation="unit",
        gold_evidence={"ok": True},
    )
    # Prior failure mode: treating ConstraintResult like a dict via .get()
    with pytest.raises(AttributeError):
        cr.get("constraint_type")  # type: ignore[attr-defined]

    prim = mod.constraint_result_to_primitives(cr)
    assert prim["passed"] is False
    assert prim["constraint_type"] == "transition"
    assert prim["involved_predicted_values"]["historical"] == "__ABSTAIN__"
    json.dumps(prim)  # must not raise


def test_extract_b2_vignette_matches_frozen_example():
    mod = _import_extract()
    rec = mod.extract_vignette(root=ROOT)
    assert rec["bundle_id"] == "ss0100_000:b:ceo:0"
    assert rec["system_id"] == "B2_latest_only"
    assert rec["n_queries"] == 8
    assert abs(rec["mean_query_accuracy"] - 0.75) < 1e-12
    assert rec["bundle_phi"] is False
    assert rec["n_correct"] == 6
    assert all(rec["narrative_checks"].values())
    # Serialization of violations must be primitive dicts
    assert rec["violations"]
    for v in rec["violations"]:
        assert isinstance(v, dict)
        assert "constraint_type" in v
        assert "passed" in v
        json.dumps(v)
