"""Tests for confirmatory naturalistic transfer artefacts."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "confirmatory" / "naturalistic_transfer"


def test_naturalistic_artefacts_frozen():
    summary = json.loads((OUT / "transfer_summary.json").read_text())
    assert summary["config"]["n_scenarios"] == 36
    assert summary["validation"]["pass"] is True
    readers = summary["readers"]
    assert readers["gold"]["mean_acc"] == 1.0
    assert readers["gold"]["bcr"] == 1.0
    assert readers["last_event_heuristic"]["bcr"] == 0.0
    assert readers["last_event_heuristic"]["mean_acc"] > readers["last_event_heuristic"]["bcr"]
    assert readers["entity_prior"]["bcr"] == 0.0
    n_lines = sum(1 for _ in (OUT / "scenarios.jsonl").open() if _.strip())
    assert n_lines == 36


def test_alt_explanations_b4_below_acc_pow_n():
    p = ROOT / "results" / "confirmatory" / "alt_explanations" / "alt_explanations_summary.json"
    d = json.loads(p.read_text())
    b4 = next(r for r in d["results"] if r["system"] == "B4_bm25_k8")
    o = b4["overall"]
    assert o["bcr"] < o["mean_expected_all_correct"]
    assert o["gap_acc_bcr"] > 0.2


def test_qwen_parser_sensitivity_bcr_floor():
    p = ROOT / "results" / "confirmatory" / "readers" / "qwen_parser_sensitivity.json"
    d = json.loads(p.read_text())
    for parser, by_sys in d["parsers"].items():
        h0 = by_sys.get("H0_ltkm_cap150_ret8") or {}
        if h0.get("n_bundles"):
            assert h0["bcr"] == 0.0
