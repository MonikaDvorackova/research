# WorldConsistMem — Anonymized Reproducibility Supplement

Double-blind ICLR supplement. No author names, institutions, or private paths.

## What this package is

Code, frozen Option A artefacts, labelled NEW robustness outputs, and scripts to:
1. verify frozen checksums and manuscript headline numbers;
2. re-run tests and smoke validation;
3. reproduce labelled NEW analyses (gold sanity, seeds, density, distractors, shortcuts, retrieval-budget).

It does **not** claim architecture superiority. Stronger LLM readers beyond the frozen Qwen2.5-3B-Instruct-4bit H4 run are **not** included as completed results.

## Environment

| Requirement | Notes |
|-------------|-------|
| Python | 3.10+ recommended |
| OS | macOS / Linux |
| Required pip | `PyYAML>=6.0`, `pytest>=7.0` (`requirements.txt`) |
| Optional LLM | Apple Silicon + `mlx-lm` + local weights for `mlx-community/Qwen2.5-3B-Instruct-4bit` |

Symbolic reproduction (freeze verification, NEW symbolic analyses, tests) does **not** need `mlx-lm`.

```bash
cd worldconsistmem   # this package root
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export PYTHONPATH=src
```

## One-command smoke test

```bash
bash scripts/smoke_repro.sh
```

Runs: pytest → frozen checksum verification → NEW gold / budget / shortcuts / ablation-reprint → asserts key NEW numbers.

Expected runtime: ~1–2 minutes on a laptop after venv creation.

**Clean-clone note:** If disk is tight, clone may omit `results/scaled/predictions/*.jsonl` (233 MiB). Those files remain in the full package under `research/experiments/worldconsistmem/` and are not required for the smoke path. See `SMOKE_REPORT.md`.

## Full NEW suite (beyond smoke)

```bash
PYTHONPATH=src python3 scripts/run_new_analyses.py all
```

Includes seeds 100–105, density, distractors, shortcuts, budget, gold, ablation reprint (~minutes).

## Frozen Option A (do not mutate)

Authoritative freeze notes: `results/scaled/FINAL_EXPERIMENT_STATUS.md`  
Metric freeze: `configs/METRIC_FREEZE.md`  
Config: `configs/scaled.yaml` (`seed_base: 100`, `worlds_per_tier: 34`)

| Object | Path |
|--------|------|
| Scaled dataset | `data/scaled/` (`manifest.json` sha256 `37aa8604…`) |
| Symbolic system table | `results/scaled/system_results.csv` (sha256 `eb5bd5fa…`) |
| Ablations | `results/scaled/ablation_results.csv` |
| Corruption suite | `results/corruption_metrics.csv` |
| Difficulty / tiers | `results/scaled/difficulty_results.csv` |
| Partial CSR | `results/scaled/partial_consistency_*.csv` |
| Symbolic predictions | `results/scaled/predictions/*.jsonl` |
| Qwen H4 Option A | `results/scaled/run2/qwen_*.csv` + `run2_predictions/` |
| Prompt / decoding | `src/worldconsistmem/llm_reader.py` (`MAX_TOKENS=48`, `TEMPERATURE=0`, evidence≤3) |

Verify:

```bash
PYTHONPATH=src python3 scripts/verify_frozen_checksums.py
```

### Full Option A regeneration (expensive; optional)

These rewrite under `results/` and should only be used on a disposable copy:

```bash
PYTHONPATH=src python3 scripts/generate_smoke.py          # smoke dataset + corruption metrics
PYTHONPATH=src python3 scripts/generate_scaled.py         # full scaled dataset (seed 100)
PYTHONPATH=src python3 scripts/run_scaled_study.py        # full symbolic study (long)
PYTHONPATH=src python3 scripts/recompute_partial_consistency.py
# LLM (optional; mlx-lm + weights):
PYTHONPATH=src python3 scripts/run_h4_llm.py
PYTHONPATH=src python3 scripts/run_h4_run2.py
PYTHONPATH=src python3 scripts/finalize_scaled.py
```

**Do not** treat regenerated outputs as Option A unless hashes match the freeze.

## Labelled NEW analyses

Scripts: `scripts/run_new_analyses.py`  
Expected outputs: `results/new/rescue_p{1,2,3}/`  
Manifest: `FROZEN_VS_NEW.md`

```bash
PYTHONPATH=src python3 scripts/run_new_analyses.py gold
PYTHONPATH=src python3 scripts/run_new_analyses.py budget
PYTHONPATH=src python3 scripts/run_new_analyses.py seeds
PYTHONPATH=src python3 scripts/run_new_analyses.py density
PYTHONPATH=src python3 scripts/run_new_analyses.py distractors
PYTHONPATH=src python3 scripts/run_new_analyses.py shortcuts
PYTHONPATH=src python3 scripts/run_new_analyses.py ablations-reprint
# or everything NEW:
PYTHONPATH=src python3 scripts/run_new_analyses.py all
```

## Metrics (Acc, Φ, BCR, Gapq)

Implemented in `src/worldconsistmem/evaluate.py`, `constraints.py`, `metrics.py`, `partial_consistency.py`.

- Acc: per-query structured exact match to gold  
- Φ: joint predicate over a bundle’s answer set under world-history constraints  
- BCR: fraction of bundles with Φ = 1  
- Gapq: Acc − BCR  

## Figures

Manuscript figures `fig1`–`fig5` are static PDF assets in the paper tree (`submission/latex/figures/`). **No figure-generation scripts are present in the original experiment repository.** Table numbers are reproducible from CSVs via `scripts/verify_frozen_checksums.py` and NEW scripts. This gap is documented, not fabricated.

## Tests

```bash
PYTHONPATH=src python3 -m pytest tests/ -q
```

## Integrity

- `INTEGRITY_MANIFEST.sha256` — sha256 of packaged files (excluding `__pycache__`, `.venv`)  
- `FROZEN_VS_NEW.md` — frozen vs NEW labelling  
- `AUDIT.md` — source audit and known gaps  

## Freeze references

- Metric freeze: `configs/METRIC_FREEZE.md`
- Experiment freeze notes: `results/scaled/FINAL_EXPERIMENT_STATUS.md`
- Smoke checksum: `3aa67ed1b6a39be3d9e1805d14f7d5ce7cc05f4655bdce0bc4ff49900c14c7ab`
- H4 protocol file: `results/scaled/h4_frozen_protocol.json` (sha256 = embedded `frozen_config_hash` `1d8a74f2…`)
- Frozen vs NEW: `FROZEN_VS_NEW.md`
- Figures: `FIGURE_REPRODUCIBILITY.md` (static PDFs; no bit-exact redraw claim)
- Clean-clone smoke: `SMOKE_REPORT.md`
- OpenReview zip: built under `publications/03-iclr-long-term-knowledge-memory/submission/package/` (see `REPRO_PACKAGE_FINAL_REPORT.md`)

## Path note

In this research repository the package lives at **`experiments/worldconsistmem/`** (also referred to as `research/experiments/worldconsistmem/` from outside the repo).
