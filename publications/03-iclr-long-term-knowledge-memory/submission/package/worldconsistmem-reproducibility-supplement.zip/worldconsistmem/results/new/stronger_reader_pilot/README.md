# NEW — Limited stronger-reader transfer pilot

**Label:** `NEW_limited_stronger_reader_transfer_pilot`  
**Not Option A.** Do not pool with frozen Option A tables.

## Predeclared design

| Item | Value |
|------|-------|
| Model | `gpt-4o-mini-2024-07-18` (`gpt-4o-mini`) |
| Examples | 149 queries in 22 complete bundles |
| Seed | `20260909` |
| Stratification | world tier × bundle difficulty (proportional); complete bundles |
| Memory system | `H0_ltkm_cap150_ret8` |
| Protocol | frozen `prompt_v3_k3_mt48` (temp=0, max_tokens=48, ≤3 evidence) |
| Est. max cost | **USD 0.017617** (cap 5.0) |
| Est. expected cost | USD 0.010134 |

## Status

Paid calls: **not executed** in prepare step. See `EXECUTION_BLOCKER.json`.

## Runner

```bash
PYTHONPATH=src python scripts/run_stronger_reader_pilot.py --execute
```

Requires `OPENAI_API_KEY`. Resumable via `api_cache.jsonl`. Stops at USD 5.0.
