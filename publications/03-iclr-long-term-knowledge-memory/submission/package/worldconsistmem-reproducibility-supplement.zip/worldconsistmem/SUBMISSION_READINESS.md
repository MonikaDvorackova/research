# Submission readiness — reproducibility package

Date: 2026-09-07  
Package root (repo-relative): `experiments/worldconsistmem/`  
OpenReview archive: `publications/03-iclr-long-term-knowledge-memory/submission/package/worldconsistmem-reproducibility-supplement.zip`

## Path reconciliation

| Reference | Meaning |
|-----------|---------|
| `experiments/worldconsistmem/` | Path relative to the research repository root |
| `research/experiments/worldconsistmem/` | Same directory when speaking from outside the repo |
| Absolute author home paths | Must not appear in the anonymized package or ZIP |

## Gate checklist

| Gate | Status |
|------|--------|
| H4 hash inconsistency fixed (`frozen_config_hash` = SHA-256 of `h4_frozen_protocol.json`) | **Yes** + pytest |
| Full NEW suite run recorded | **Yes** (940s PASS) |
| Figure reproducibility documented (no false claim of drawing scripts) | **Yes** |
| Clean-clone smoke **with** predictions | **Yes** (94 pytest, 238s PASS) |
| OpenReview ZIP built + anonymized + hashed | **Yes** |
| Option A scientific CSVs/predictions mutated | **No** |
| Scientific manuscript claims rewritten | **No** (repro wording only earlier) |

## Verification taxonomy

1. **Verified by clean-clone execution:** smoke_repro.sh; freeze hashes; H4 protocol hash test; NEW smoke subset.  
2. **Verified by hash/presence:** full prediction jsonl set (`PREDICTIONS_INTEGRITY.json`); integrity manifests.  
3. **Not reproducible in current environment:** Qwen/Phi re-inference without `mlx_lm`+weights; bit-exact manuscript figure redraw (no original plot scripts).

## Archive

See companion `worldconsistmem-reproducibility-supplement.sha256` next to the ZIP for the authoritative archive digest (regenerated with the ZIP).

## Verdict

**Reproducibility package is ready to attach as anonymized OpenReview supplementary material**, with explicit limitations for LLM re-inference and figure artwork.

This is **not** a claim that the full ICLR paper is scientifically acceptance-ready—only that the packaging/integrity gates listed above are closed.
