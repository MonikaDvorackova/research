"""WorldConsistMem: evolving-world consistency benchmark core."""

__version__ = "0.1.0"
